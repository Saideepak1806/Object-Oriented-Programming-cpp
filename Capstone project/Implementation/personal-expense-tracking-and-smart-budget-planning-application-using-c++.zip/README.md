# Personal Expense Tracking and Smart Budget Planning Application

A modern, dark-themed personal finance and budget planning web application built with **React, TypeScript, Tailwind CSS, Chart.js**, and an architecture designed for a native **C++17 (cpp-httplib) + SQLite3** backend in Indian Rupees (**₹ INR**).

---

## Part 1: How to Run the Web Application (Frontend)

### Prerequisites
- **Node.js** (v18 or higher recommended): [Download Node.js](https://nodejs.org/)
- **npm** (comes bundled with Node.js)

### Step-by-Step Instructions

1. **Extract the downloaded ZIP file**:
   Extract the archive to a folder on your computer (e.g. `personal-expense-tracker`).

2. **Open your Terminal or Command Prompt**:
   Navigate into the extracted project directory:
   ```bash
   cd path/to/extracted-folder
   ```

3. **Install Dependencies**:
   Run the following command to install all packages:
   ```bash
   npm install
   ```

4. **Start the Development Server**:
   ```bash
   npm run dev
   ```

5. **Open in Your Browser**:
   Open your web browser and go to:
   ```
   http://localhost:3000
   ```

6. **Sign In / Register**:
   - The application opens directly to the **Login / Register** screen.
   - Click **Register New Account**, enter your name, email, and password, and create your account.
   - Your dashboard will initialize with **₹0.00** ready for you to record transactions and configure monthly budget limits.

---

## Part 2: (Optional) How to Run the Native C++17 Backend

The folder `cpp_backend` contains the native C++17 REST API server using `cpp-httplib`, SQLite3, and `nlohmann/json`.

### Prerequisites
- C++17 compiler (`g++` or `clang++`)
- SQLite3 development library (`libsqlite3-dev` on Ubuntu/Debian, `sqlite3` on macOS)
- `make` utility

### Linux (Ubuntu / Debian)
```bash
# 1. Install prerequisites
sudo apt-get update
sudo apt-get install -y build-essential libsqlite3-dev curl

# 2. Navigate to the backend directory
cd cpp_backend

# 3. Download the two header-only dependencies
curl -sL https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h -o httplib.h
curl -sL https://raw.githubusercontent.com/nlohmann/json/develop/single_include/nlohmann/json.hpp -o nlohmann/json.hpp # or place json.hpp in directory

# 4. Compile the server
make
# or directly:
g++ -std=c++17 main.cpp -lsqlite3 -lpthread -O2 -o expense_server

# 5. Run the server on port 8080
./expense_server 8080
```

### macOS (Terminal)
```bash
# 1. Install SQLite via Homebrew (if not already installed)
brew install sqlite3

# 2. Navigate to backend directory and compile
cd cpp_backend
g++ -std=c++17 main.cpp -lsqlite3 -lpthread -O2 -o expense_server

# 3. Run
./expense_server 8080
```

### Windows (MinGW-w64 or WSL)
- Recommended: Run inside **WSL (Windows Subsystem for Linux)** using the Ubuntu instructions above, or compile with **MinGW-w64**:
  ```bash
  g++ -std=c++17 main.cpp -lsqlite3 -lws2_32 -lpthread -O2 -o expense_server.exe
  ./expense_server.exe 8080
  ```

---

## Connecting the Frontend to the C++ Server

1. With both the frontend (`http://localhost:3000`) and the C++ server (`http://localhost:8080`) running:
2. In the web app, click **C++ Backend** in the left sidebar.
3. Click **Test C++ Connection** to ping `http://localhost:8080/api/health`.
4. Switch the toggle from **Client Prototype** to **Live C++ Server Mode**.
