import { Transaction, BudgetConfig, UserAccount, ExpenseCategory, BackendStatus } from '../types';
import { EMPTY_BUDGETS, DEFAULT_OVERALL_BUDGET } from '../constants/categories';

const USERS_STORAGE_KEY = 'cxx_users_registry_v2';
const CURRENT_SESSION_KEY = 'cxx_current_auth_session_v2';
const BACKEND_CONFIG_KEY = 'cxx_backend_config_v2';

class ApiService {
  private backendStatus: BackendStatus;

  constructor() {
    // Purge old prototype dummy data if present
    try {
      localStorage.removeItem('cxx_expense_tracker_transactions_v1');
      localStorage.removeItem('cxx_expense_tracker_budgets_v1');
      localStorage.removeItem('cxx_expense_tracker_user_v1');
    } catch {
      // Ignore if localStorage unavailable
    }

    const savedConfig = localStorage.getItem(BACKEND_CONFIG_KEY);
    if (savedConfig) {
      try {
        this.backendStatus = JSON.parse(savedConfig);
      } catch {
        this.backendStatus = {
          mode: 'client_prototype',
          serverUrl: 'http://localhost:8080',
          isOnline: false,
        };
      }
    } else {
      this.backendStatus = {
        mode: 'client_prototype',
        serverUrl: 'http://localhost:8080',
        isOnline: false,
      };
    }
  }

  // --- Authentication & User Accounts ---
  public getRegisteredUsers(): UserAccount[] {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getCurrentUser(): UserAccount | null {
    const raw = localStorage.getItem(CURRENT_SESSION_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  public register(
    name: string,
    email: string,
    password: string,
    role = 'Personal Budget User'
  ): { success: boolean; user?: UserAccount; error?: string } {
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedName = name.trim();

    if (!trimmedName) {
      return { success: false, error: 'Full name is required.' };
    }
    if (!trimmedEmail) {
      return { success: false, error: 'Email address is required.' };
    }
    if (!password || password.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters long.' };
    }

    const users = this.getRegisteredUsers();
    const existing = users.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (existing) {
      return {
        success: false,
        error: 'An account with this email already exists. Please log in.',
      };
    }

    const newUser: UserAccount = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: trimmedName,
      email: trimmedEmail,
      password: password,
      currency: '₹',
      role: role.trim() || 'Personal Budget User',
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));

    // Automatically set current session on registration
    localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(newUser));
    return { success: true, user: newUser };
  }

  public login(
    email: string,
    password: string
  ): { success: boolean; user?: UserAccount; error?: string } {
    const trimmedEmail = email.trim().toLowerCase();
    const users = this.getRegisteredUsers();

    const user = users.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (!user) {
      return {
        success: false,
        error: 'No account found with this email. Please register first.',
      };
    }

    if (user.password !== password) {
      return {
        success: false,
        error: 'Invalid password. Please verify and try again.',
      };
    }

    localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(user));
    return { success: true, user };
  }

  public logout(): void {
    localStorage.removeItem(CURRENT_SESSION_KEY);
  }

  public updateUserProfile(updatedUser: UserAccount): UserAccount {
    const users = this.getRegisteredUsers();
    const idx = users.findIndex((u) => u.id === updatedUser.id);
    if (idx !== -1) {
      users[idx] = { ...updatedUser };
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    }
    localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(updatedUser));
    return updatedUser;
  }

  // --- Transactions (Strictly user-scoped, no dummy data) ---
  private getTxStorageKey(userId: string): string {
    return `cxx_tx_v2_${userId}`;
  }

  public getTransactions(userId: string): Transaction[] {
    if (!userId) return [];
    const stored = localStorage.getItem(this.getTxStorageKey(userId));
    if (!stored) {
      return []; // Clean empty array for every user, no dummy entries
    }
    try {
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  public addTransaction(
    userId: string,
    transaction: Omit<Transaction, 'id' | 'userId' | 'createdAt'>
  ): Transaction {
    const transactions = this.getTransactions(userId);
    const newTx: Transaction = {
      ...transaction,
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      createdAt: new Date().toISOString(),
    };
    transactions.unshift(newTx);
    localStorage.setItem(this.getTxStorageKey(userId), JSON.stringify(transactions));
    return newTx;
  }

  public updateTransaction(userId: string, updatedTx: Transaction): Transaction {
    const transactions = this.getTransactions(userId);
    const index = transactions.findIndex((tx) => tx.id === updatedTx.id);
    if (index !== -1) {
      transactions[index] = { ...updatedTx, userId };
      localStorage.setItem(this.getTxStorageKey(userId), JSON.stringify(transactions));
    }
    return updatedTx;
  }

  public deleteTransaction(userId: string, id: string): boolean {
    const transactions = this.getTransactions(userId);
    const filtered = transactions.filter((tx) => tx.id !== id);
    localStorage.setItem(this.getTxStorageKey(userId), JSON.stringify(filtered));
    return true;
  }

  // --- Budgets (Strictly user-scoped, no assumed limits) ---
  private getBudgetStorageKey(userId: string, month: string): string {
    return `cxx_budget_v2_${userId}_${month}`;
  }

  public getBudgets(userId: string, month: string): BudgetConfig {
    if (!userId) {
      return {
        month,
        overallLimit: DEFAULT_OVERALL_BUDGET,
        categories: { ...EMPTY_BUDGETS },
      };
    }
    const stored = localStorage.getItem(this.getBudgetStorageKey(userId, month));
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        // fallback
      }
    }
    // Default is 0 until user sets it
    const emptyConfig: BudgetConfig = {
      month,
      overallLimit: 0,
      categories: { ...EMPTY_BUDGETS },
    };
    return emptyConfig;
  }

  public updateBudgets(userId: string, config: BudgetConfig): BudgetConfig {
    if (!userId) return config;
    localStorage.setItem(
      this.getBudgetStorageKey(userId, config.month),
      JSON.stringify(config)
    );
    return config;
  }

  // --- Backend Status & C++ Integration ---
  public getBackendStatus(): BackendStatus {
    return { ...this.backendStatus };
  }

  public setBackendConfig(config: Partial<BackendStatus>): BackendStatus {
    this.backendStatus = { ...this.backendStatus, ...config };
    localStorage.setItem(BACKEND_CONFIG_KEY, JSON.stringify(this.backendStatus));
    return { ...this.backendStatus };
  }

  public async pingCppServer(
    url?: string
  ): Promise<{ success: boolean; latencyMs: number; message: string }> {
    const targetUrl = url || this.backendStatus.serverUrl;
    const start = performance.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${targetUrl}/api/health`, {
        method: 'GET',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      const latencyMs = Math.round(performance.now() - start);

      if (res.ok) {
        this.setBackendConfig({
          isOnline: true,
          latencyMs,
          lastChecked: new Date().toISOString(),
        });
        return {
          success: true,
          latencyMs,
          message: `Connected to C++17 cpp-httplib server at ${targetUrl}`,
        };
      } else {
        this.setBackendConfig({
          isOnline: false,
          latencyMs,
          lastChecked: new Date().toISOString(),
        });
        return {
          success: false,
          latencyMs,
          message: `HTTP ${res.status}: C++ server error`,
        };
      }
    } catch (err: unknown) {
      const latencyMs = Math.round(performance.now() - start);
      this.setBackendConfig({
        isOnline: false,
        latencyMs,
        lastChecked: new Date().toISOString(),
      });
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      return {
        success: false,
        latencyMs,
        message: `Unable to connect to ${targetUrl} (${errorMessage}). Local prototype active.`,
      };
    }
  }
}

export const apiService = new ApiService();
