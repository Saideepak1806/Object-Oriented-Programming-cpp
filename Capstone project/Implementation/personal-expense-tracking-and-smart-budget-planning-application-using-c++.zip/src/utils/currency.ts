/**
 * Standard Indian Rupee (INR) currency formatter.
 * Formats numbers in the Indian numbering system (e.g. ₹1,500.00, ₹1,25,000.00).
 */
export function formatINR(amount: number, showSign = false): string {
  const isNegative = amount < 0;
  const abs = Math.abs(amount || 0);
  const formatted = abs.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  if (showSign) {
    return isNegative ? `-₹${formatted}` : `+₹${formatted}`;
  }
  return isNegative ? `-₹${formatted}` : `₹${formatted}`;
}

export function formatINRCompact(amount: number): string {
  const abs = Math.abs(amount || 0);
  if (abs >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  }
  if (abs >= 100000) {
    return `₹${(amount / 100000).toFixed(2)} L`;
  }
  if (abs >= 1000) {
    return `₹${(amount / 1000).toFixed(1)}k`;
  }
  return formatINR(amount);
}
