export type TransactionType = 'expense' | 'income';

export type ExpenseCategory =
  | 'Food'
  | 'Transport'
  | 'Education'
  | 'Shopping'
  | 'Entertainment'
  | 'Healthcare'
  | 'Others';

export type IncomeCategory =
  | 'Salary'
  | 'Freelance'
  | 'Investments'
  | 'Grants & Scholarships'
  | 'Other Income';

export type Category = ExpenseCategory | IncomeCategory;

export type PaymentMethod = 'Card' | 'Cash' | 'Bank Transfer' | 'UPI / Digital';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  category: Category;
  description: string;
  date: string; // ISO YYYY-MM-DD
  paymentMethod: PaymentMethod;
  notes?: string;
  createdAt?: string;
}

export interface CategoryBudget {
  category: ExpenseCategory;
  limit: number;
}

export interface BudgetConfig {
  month: string; // e.g. "2026-11"
  overallLimit: number;
  categories: Record<ExpenseCategory, number>;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password?: string;
  currency: string;
  role: string;
  createdAt: string;
}

export interface BackendStatus {
  mode: 'client_prototype' | 'cpp_server';
  serverUrl: string;
  isOnline: boolean;
  lastChecked?: string;
  latencyMs?: number;
}
