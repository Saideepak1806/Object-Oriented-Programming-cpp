import { ExpenseCategory, IncomeCategory } from '../types';

export const EXPENSE_CATEGORIES: {
  id: ExpenseCategory;
  name: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
}[] = [
  {
    id: 'Food',
    name: 'Food & Dining',
    color: '#f97316', // orange-500
    bgColor: 'rgba(249, 115, 22, 0.15)',
    borderColor: '#f97316',
    icon: 'Utensils',
  },
  {
    id: 'Transport',
    name: 'Transport & Transit',
    color: '#3b82f6', // blue-500
    bgColor: 'rgba(59, 130, 246, 0.15)',
    borderColor: '#3b82f6',
    icon: 'Car',
  },
  {
    id: 'Education',
    name: 'Education & Learning',
    color: '#8b5cf6', // violet-500
    bgColor: 'rgba(139, 92, 246, 0.15)',
    borderColor: '#8b5cf6',
    icon: 'GraduationCap',
  },
  {
    id: 'Shopping',
    name: 'Shopping & Apparel',
    color: '#ec4899', // pink-500
    bgColor: 'rgba(236, 72, 153, 0.15)',
    borderColor: '#ec4899',
    icon: 'ShoppingBag',
  },
  {
    id: 'Entertainment',
    name: 'Entertainment & Leisure',
    color: '#06b6d4', // cyan-500
    bgColor: 'rgba(6, 182, 212, 0.15)',
    borderColor: '#06b6d4',
    icon: 'Film',
  },
  {
    id: 'Healthcare',
    name: 'Healthcare & Medical',
    color: '#10b981', // emerald-500
    bgColor: 'rgba(16, 185, 129, 0.15)',
    borderColor: '#10b981',
    icon: 'HeartPulse',
  },
  {
    id: 'Others',
    name: 'Others & Misc',
    color: '#94a3b8', // slate-400
    bgColor: 'rgba(148, 163, 184, 0.15)',
    borderColor: '#94a3b8',
    icon: 'Layers',
  },
];

export const INCOME_CATEGORIES: {
  id: IncomeCategory;
  name: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
}[] = [
  {
    id: 'Salary',
    name: 'Regular Salary',
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.15)',
    borderColor: '#10b981',
    icon: 'Briefcase',
  },
  {
    id: 'Freelance',
    name: 'Freelance & Consulting',
    color: '#14b8a6',
    bgColor: 'rgba(20, 184, 166, 0.15)',
    borderColor: '#14b8a6',
    icon: 'Laptop',
  },
  {
    id: 'Investments',
    name: 'Investments & Dividends',
    color: '#6366f1',
    bgColor: 'rgba(99, 102, 241, 0.15)',
    borderColor: '#6366f1',
    icon: 'TrendingUp',
  },
  {
    id: 'Grants & Scholarships',
    name: 'Grants & Scholarships',
    color: '#eab308',
    bgColor: 'rgba(234, 179, 8, 0.15)',
    borderColor: '#eab308',
    icon: 'Award',
  },
  {
    id: 'Other Income',
    name: 'Other Inflows',
    color: '#64748b',
    bgColor: 'rgba(100, 116, 139, 0.15)',
    borderColor: '#64748b',
    icon: 'PlusCircle',
  },
];

// No assumed budgets: all default to 0.00 until user configures them
export const EMPTY_BUDGETS: Record<ExpenseCategory, number> = {
  Food: 0,
  Transport: 0,
  Education: 0,
  Shopping: 0,
  Entertainment: 0,
  Healthcare: 0,
  Others: 0,
};

export const DEFAULT_OVERALL_BUDGET = 0;
