/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { TransactionsView } from './components/TransactionsView';
import { BudgetView } from './components/BudgetView';
import { ReportsView } from './components/ReportsView';
import { CppBackendView } from './components/CppBackendView';
import { TransactionModal } from './components/TransactionModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { BudgetModal } from './components/BudgetModal';
import { AuthModal } from './components/AuthModal';
import { apiService } from './services/apiService';
import { Transaction, BudgetConfig, UserAccount, BackendStatus } from './types';
import { EMPTY_BUDGETS } from './constants/categories';

export default function App() {
  // Authentication gate: login is the first screen
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    return apiService.getCurrentUser();
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [activeMonth, setActiveMonth] = useState<string>(() => {
    return new Date().toISOString().substring(0, 7); // e.g. "2026-11"
  });

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgetConfig, setBudgetConfig] = useState<BudgetConfig>({
    month: new Date().toISOString().substring(0, 7),
    overallLimit: 0,
    categories: { ...EMPTY_BUDGETS },
  });

  const [backendStatus, setBackendStatus] = useState<BackendStatus>({
    mode: 'client_prototype',
    serverUrl: 'http://localhost:8080',
    isOnline: false,
  });

  // Modal States
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [txToEdit, setTxToEdit] = useState<Transaction | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [txToDelete, setTxToDelete] = useState<Transaction | null>(null);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Load user data whenever currentUser changes
  useEffect(() => {
    if (currentUser) {
      const userTx = apiService.getTransactions(currentUser.id);
      setTransactions(userTx);

      const userBudgets = apiService.getBudgets(currentUser.id, activeMonth);
      setBudgetConfig(userBudgets);

      const loadedBackend = apiService.getBackendStatus();
      setBackendStatus(loadedBackend);
    } else {
      setTransactions([]);
      setBudgetConfig({
        month: activeMonth,
        overallLimit: 0,
        categories: { ...EMPTY_BUDGETS },
      });
    }
  }, [currentUser, activeMonth]);

  // Handle successful login or registration
  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUser(user);
    setActiveTab('dashboard');
  };

  // Handle logout: returns user directly to the Login / Register screen
  const handleLogout = () => {
    apiService.logout();
    setCurrentUser(null);
    setActiveTab('dashboard');
    setIsMobileNavOpen(false);
    setIsProfileModalOpen(false);
  };

  // Transaction Actions (Strictly user-scoped)
  const handleOpenAddModal = () => {
    setTxToEdit(null);
    setIsTxModalOpen(true);
  };

  const handleOpenEditModal = (tx: Transaction) => {
    setTxToEdit(tx);
    setIsTxModalOpen(true);
  };

  const handleOpenDeleteModal = (tx: Transaction) => {
    setTxToDelete(tx);
    setIsDeleteModalOpen(true);
  };

  const handleSaveTransaction = (
    txData: Omit<Transaction, 'id' | 'userId' | 'createdAt'>,
    existingId?: string
  ) => {
    if (!currentUser) return;

    if (existingId) {
      const updated = apiService.updateTransaction(currentUser.id, {
        ...txData,
        id: existingId,
        userId: currentUser.id,
      });
      setTransactions((prev) =>
        prev.map((t) => (t.id === existingId ? updated : t))
      );
    } else {
      const created = apiService.addTransaction(currentUser.id, txData);
      setTransactions((prev) => [created, ...prev]);
    }
  };

  const handleConfirmDelete = () => {
    if (!currentUser || !txToDelete) return;
    apiService.deleteTransaction(currentUser.id, txToDelete.id);
    setTransactions((prev) => prev.filter((t) => t.id !== txToDelete.id));
    setTxToDelete(null);
  };

  // Budget Actions
  const handleSaveBudgets = (newConfig: BudgetConfig) => {
    if (!currentUser) return;
    const updated = apiService.updateBudgets(currentUser.id, newConfig);
    setBudgetConfig({ ...updated });
  };

  // User Profile Actions
  const handleUpdateUser = (updated: UserAccount) => {
    const saved = apiService.updateUserProfile(updated);
    setCurrentUser(saved);
  };

  // Backend C++ Ping
  const handlePingBackend = async (url: string) => {
    const res = await apiService.pingCppServer(url);
    setBackendStatus(apiService.getBackendStatus());
    return res;
  };

  const handleUpdateBackendConfig = (config: Partial<BackendStatus>) => {
    const updated = apiService.setBackendConfig(config);
    setBackendStatus(updated);
  };

  // REQUIREMENT 1: Login must be the first screen. Do not show dashboard before authentication.
  if (!currentUser) {
    return <AuthScreen onLoginSuccess={handleLoginSuccess} />;
  }

  // Monthly spent calculated from user's current month transactions
  const currentMonthSpent = transactions
    .filter((tx) => tx.date.startsWith(budgetConfig.month) && tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Navigation with Logout Action */}
      <Navbar
        currentUser={currentUser}
        backendStatus={backendStatus}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenAddModal={handleOpenAddModal}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        onOpenCppHub={() => setActiveTab('cpp_backend')}
        onLogout={handleLogout}
        onToggleMobileMenu={() => setIsMobileNavOpen((prev) => !prev)}
      />

      {/* Main Workspace: Sidebar + Viewport */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          currentUser={currentUser}
          backendStatus={backendStatus}
          monthlySpent={currentMonthSpent}
          overallBudget={budgetConfig.overallLimit}
          onOpenProfileModal={() => setIsProfileModalOpen(true)}
          onOpenBudgetModal={() => setIsBudgetModalOpen(true)}
          onLogout={handleLogout}
          isMobileOpen={isMobileNavOpen}
          onCloseMobile={() => setIsMobileNavOpen(false)}
        />

        {/* Viewport Content Area */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full overflow-x-hidden">
          {activeTab === 'dashboard' && (
            <DashboardView
              transactions={transactions}
              budgetConfig={budgetConfig}
              currentUser={currentUser}
              onOpenAddModal={handleOpenAddModal}
              onOpenBudgetModal={() => setIsBudgetModalOpen(true)}
              onEditTransaction={handleOpenEditModal}
              onDeleteTransaction={handleOpenDeleteModal}
              onNavigateToTransactions={() => setActiveTab('transactions')}
              onNavigateToBudget={() => setActiveTab('budget')}
            />
          )}

          {activeTab === 'transactions' && (
            <TransactionsView
              transactions={transactions}
              onOpenAddModal={handleOpenAddModal}
              onEditTransaction={handleOpenEditModal}
              onDeleteTransaction={handleOpenDeleteModal}
            />
          )}

          {activeTab === 'budget' && (
            <BudgetView
              budgetConfig={budgetConfig}
              transactions={transactions}
              onOpenBudgetModal={() => setIsBudgetModalOpen(true)}
              onOpenAddModal={handleOpenAddModal}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView transactions={transactions} />
          )}

          {activeTab === 'cpp_backend' && (
            <CppBackendView
              backendStatus={backendStatus}
              onPingBackend={handlePingBackend}
              onUpdateConfig={handleUpdateBackendConfig}
            />
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-4 md:px-8 py-3 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span>Personal Expense Tracking & Smart Budget Planning</span>
          <span>·</span>
          <span className="font-mono text-[11px] text-slate-400">Standard Currency: ₹ INR</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>C++17 SQLite Backend Specification</span>
          <span>·</span>
          <span>Active User: {currentUser.name}</span>
        </div>
      </footer>

      {/* Modals & Dialogs */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => setIsTxModalOpen(false)}
        onSave={handleSaveTransaction}
        transactionToEdit={txToEdit}
      />

      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        transaction={txToDelete}
      />

      <BudgetModal
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        currentBudget={budgetConfig}
        onSave={handleSaveBudgets}
      />

      <AuthModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={handleUpdateUser}
        onLogout={handleLogout}
      />
    </div>
  );
}
