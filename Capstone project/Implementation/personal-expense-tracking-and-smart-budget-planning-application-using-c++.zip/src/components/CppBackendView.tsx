import React, { useState } from 'react';
import {
  Terminal,
  Database,
  Cpu,
  Layers,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
} from 'lucide-react';
import { BackendStatus } from '../types';

interface CppBackendViewProps {
  backendStatus: BackendStatus;
  onPingBackend: (url: string) => Promise<{ success: boolean; latencyMs: number; message: string }>;
  onUpdateConfig: (config: Partial<BackendStatus>) => void;
}

export const CppBackendView: React.FC<CppBackendViewProps> = ({
  backendStatus,
  onPingBackend,
  onUpdateConfig,
}) => {
  const [serverUrl, setServerUrl] = useState(backendStatus.serverUrl);
  const [isPinging, setIsPinging] = useState(false);
  const [pingResult, setPingResult] = useState<{
    success: boolean;
    latencyMs: number;
    message: string;
  } | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'main' | 'schema' | 'makefile' | 'spec'>('main');
  const [copiedTab, setCopiedTab] = useState<string | null>(null);

  const handleTestConnection = async () => {
    setIsPinging(true);
    setPingResult(null);
    try {
      const res = await onPingBackend(serverUrl);
      setPingResult(res);
    } catch (err: any) {
      setPingResult({
        success: false,
        latencyMs: 0,
        message: err.message || 'Connection failed',
      });
    } finally {
      setIsPinging(false);
    }
  };

  const handleSwitchMode = (mode: 'client_prototype' | 'cpp_server') => {
    onUpdateConfig({ mode, serverUrl });
  };

  const copyCode = (code: string, tabName: string) => {
    navigator.clipboard.writeText(code);
    setCopiedTab(tabName);
    setTimeout(() => setCopiedTab(null), 1500);
  };

  const cppMainCode = `/**
 * Personal Expense Tracking & Smart Budget Planning Application
 * Backend Architecture: C++17 (cpp-httplib) + SQLite3 + nlohmann/json
 * Standard Currency: Indian Rupee (₹ INR)
 *
 * Build Command:
 *   g++ -std=c++17 main.cpp -lsqlite3 -lpthread -O2 -o expense_server
 */
#include <iostream>
#include <string>
#include <vector>
#include <sqlite3.h>
#include "httplib.h"
#include "nlohmann/json.hpp"

using json = nlohmann::json;

class Database {
    sqlite3* db;
public:
    Database(const std::string& path) {
        sqlite3_open(path.c_str(), &db);
        init();
    }
    ~Database() { if (db) sqlite3_close(db); }
    void init() {
        const char* sql = R"(
            PRAGMA foreign_keys = ON;
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                currency TEXT DEFAULT '₹',
                role TEXT DEFAULT 'Personal Budget User',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
                amount REAL NOT NULL CHECK(amount > 0),
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                date TEXT NOT NULL,
                payment_method TEXT NOT NULL,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS budgets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                month TEXT NOT NULL,
                category TEXT NOT NULL,
                budget_limit REAL NOT NULL,
                UNIQUE(user_id, month, category),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
        )";
        sqlite3_exec(db, sql, nullptr, nullptr, nullptr);
    }
    sqlite3* handle() { return db; }
};

int main(int argc, char* argv[]) {
    int port = argc > 1 ? std::stoi(argv[1]) : 8080;
    Database db("expenses.db");
    httplib::Server svr;

    // CORS Headers
    auto cors = [](httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin", "*");
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    };

    svr.Options(".*", [cors](const auto&, auto& res) { cors(res); res.status = 204; });

    // Health & Info Endpoint
    svr.Get("/api/health", [cors](const auto&, auto& res) {
        cors(res);
        json j = {
            {"status", "online"},
            {"engine", "C++17 (cpp-httplib)"},
            {"database", "SQLite3 (expenses.db)"},
            {"currency", "INR (₹)"}
        };
        res.set_content(j.dump(), "application/json");
    });

    // GET /api/transactions
    svr.Get("/api/transactions", [&db, cors](const auto& req, auto& res) {
        cors(res);
        std::string userId = req.has_param("userId") ? req.get_param_value("userId") : "";
        sqlite3_stmt* stmt;
        json arr = json::array();
        std::string sql = "SELECT id, user_id, type, amount, category, description, date, payment_method, notes FROM transactions WHERE user_id = ? ORDER BY date DESC";
        if (sqlite3_prepare_v2(db.handle(), sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_text(stmt, 1, userId.c_str(), -1, SQLITE_TRANSIENT);
            while (sqlite3_step(stmt) == SQLITE_ROW) {
                json tx;
                tx["id"] = (const char*)sqlite3_column_text(stmt, 0);
                tx["userId"] = (const char*)sqlite3_column_text(stmt, 1);
                tx["type"] = (const char*)sqlite3_column_text(stmt, 2);
                tx["amount"] = sqlite3_column_double(stmt, 3);
                tx["category"] = (const char*)sqlite3_column_text(stmt, 4);
                tx["description"] = (const char*)sqlite3_column_text(stmt, 5);
                tx["date"] = (const char*)sqlite3_column_text(stmt, 6);
                tx["paymentMethod"] = (const char*)sqlite3_column_text(stmt, 7);
                const char* n = (const char*)sqlite3_column_text(stmt, 8);
                tx["notes"] = n ? n : "";
                arr.push_back(tx);
            }
            sqlite3_finalize(stmt);
        }
        res.set_content(arr.dump(), "application/json");
    });

    std::cout << "[C++17 Server] Listening on http://0.0.0.0:" << port << " (INR ₹)" << std::endl;
    svr.listen("0.0.0.0", port);
    return 0;
}`;

  const schemaSql = `-- SQLite Database Schema: expenses.db
-- Standard Currency: Indian Rupee (₹ INR)
PRAGMA foreign_keys = ON;

-- Users Table with Credentials
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    currency TEXT DEFAULT '₹',
    role TEXT DEFAULT 'Personal Budget User',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Budgets Table (user-controlled per month and category in INR)
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    month TEXT NOT NULL, -- Format: YYYY-MM
    category TEXT NOT NULL, -- 'Overall' or 'Food', 'Transport', etc.
    budget_limit REAL NOT NULL, -- Stored in INR (₹)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, month, category),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Transactions Table (user-scoped records)
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
    amount REAL NOT NULL CHECK(amount > 0), -- Amount in INR (₹)
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    date TEXT NOT NULL, -- Format: YYYY-MM-DD
    payment_method TEXT NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_tx_cat ON transactions(category);
CREATE INDEX IF NOT EXISTS idx_budgets ON budgets(user_id, month);`;

  const makefileCode = `# Compilation Makefile for C++17 Backend
CXX = g++
CXXFLAGS = -std=c++17 -Wall -Wextra -O2
LDFLAGS = -lsqlite3 -lpthread

TARGET = expense_server
SRCS = main.cpp

all: $(TARGET)

$(TARGET): $(SRCS)
\t$(CXX) $(CXXFLAGS) $(SRCS) $(LDFLAGS) -o $(TARGET)

run: $(TARGET)
\t./$(TARGET) 8080

clean:
\trm -f $(TARGET) expenses.db`;

  const specMarkdown = `### REST API Specification (C++17 cpp-httplib)
Base URL: http://localhost:8080/api
Currency: Indian Rupee (₹ INR)

1. GET /api/health
   - Returns: { "status": "online", "engine": "C++17 (cpp-httplib)", "database": "SQLite3", "currency": "INR (₹)" }

2. POST /api/auth/register
   - Body: { "name": "Deepak", "email": "deepak@example.com", "password": "••••" }
   - Returns: { "success": true, "user": { "id": "usr-1", "name": "Deepak", "currency": "₹" } }

3. POST /api/auth/login
   - Body: { "email": "deepak@example.com", "password": "••••" }
   - Returns: { "success": true, "user": { ... } }

4. GET /api/transactions?userId=usr-1
   - Returns: Array of user's transactions in INR (₹)

5. POST /api/transactions
   - Body: { "userId": "usr-1", "type": "expense", "amount": 1500.0, "category": "Food", "description": "Groceries", "date": "2026-11-01", "paymentMethod": "UPI / Digital" }
   - Returns: Created transaction with assigned ID

6. GET /api/budgets?userId=usr-1&month=2026-11
   - Returns: User's set limits in ₹ INR`;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Terminal className="w-5 h-5 text-emerald-400" />
          <span>C++17 & SQLite Backend Architecture Hub</span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Pure C++17 systems architecture using cpp-httplib, SQLite3, and nlohmann/json in Indian Rupee (₹ INR). No Python, Flask, Node.js or Firebase backends.
        </p>
      </div>

      {/* Architecture Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-300">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <h2 className="text-xs font-semibold">C++17 Server Engine</h2>
          </div>
          <p className="text-xs text-slate-400">
            High-performance, lightweight multi-threaded HTTP/HTTPS REST server utilizing <strong className="text-slate-200">cpp-httplib</strong> with zero external runtime daemon requirements.
          </p>
          <div className="text-[11px] font-mono text-emerald-400 pt-1">
            Library: yhirose/cpp-httplib
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-300">
            <Database className="w-4 h-4 text-blue-400" />
            <h2 className="text-xs font-semibold">Embedded SQLite3</h2>
          </div>
          <p className="text-xs text-slate-400">
            ACID-compliant relational database file (<code className="text-slate-200">expenses.db</code>). Stores normalized tables for users, transactions, and category budget limits.
          </p>
          <div className="text-[11px] font-mono text-blue-400 pt-1">
            Engine: SQLite 3.x C API
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-300">
            <Layers className="w-4 h-4 text-violet-400" />
            <h2 className="text-xs font-semibold">nlohmann/json Serialization</h2>
          </div>
          <p className="text-xs text-slate-400">
            Modern C++ header-only JSON parser and serializer with direct mapping to standard STL containers (<code className="text-slate-200">std::vector</code>, <code className="text-slate-200">std::string</code>).
          </p>
          <div className="text-[11px] font-mono text-violet-400 pt-1">
            Currency Standard: ₹ INR
          </div>
        </div>
      </div>

      {/* Backend Mode Switcher & Live Connection Panel */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-white">Backend Connection Controller</h2>
            <p className="text-xs text-slate-400">
              Run this frontend prototype in Browser Prototype mode or connect directly to your compiled C++ binary
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
            <button
              type="button"
              onClick={() => handleSwitchMode('client_prototype')}
              className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                backendStatus.mode === 'client_prototype'
                  ? 'bg-slate-800 text-white shadow-xs font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Client Prototype (Active)
            </button>
            <button
              type="button"
              onClick={() => handleSwitchMode('cpp_server')}
              className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                backendStatus.mode === 'cpp_server'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live C++ Server Mode
            </button>
          </div>
        </div>

        {/* Server Endpoint & Ping */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
          <div className="md:col-span-8 flex items-center gap-2">
            <span className="text-xs text-slate-400 whitespace-nowrap">Server URL:</span>
            <input
              type="text"
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
              placeholder="http://localhost:8080"
              className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono focus:outline-hidden focus:border-emerald-500"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isPinging}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
              <span>{isPinging ? 'Pinging /api/health...' : 'Test C++ Connection'}</span>
            </button>
          </div>
        </div>

        {/* Ping Result Feedback */}
        {pingResult && (
          <div
            className={`p-3 rounded-lg border text-xs ${
              pingResult.success
                ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
                : 'bg-slate-950 border-slate-800 text-slate-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {pingResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              <span className="font-medium">{pingResult.message}</span>
              {pingResult.latencyMs > 0 && (
                <span className="ml-auto font-mono text-[11px] text-slate-400">
                  Latency: {pingResult.latencyMs}ms
                </span>
              )}
            </div>
            {!pingResult.success && (
              <p className="mt-1 text-[11px] text-slate-400">
                To launch the C++ server locally, compile <code className="text-slate-300">cpp_backend/main.cpp</code> with <code className="text-slate-300">make run</code> on your machine!
              </p>
            )}
          </div>
        )}
      </div>

      {/* Code Inspector Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 px-4 bg-slate-950/70">
          <div className="flex items-center gap-1 text-xs">
            <button
              onClick={() => setActiveCodeTab('main')}
              className={`py-3 px-3 font-medium transition-colors border-b-2 ${
                activeCodeTab === 'main'
                  ? 'border-emerald-500 text-emerald-400 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              main.cpp (C++17)
            </button>
            <button
              onClick={() => setActiveCodeTab('schema')}
              className={`py-3 px-3 font-medium transition-colors border-b-2 ${
                activeCodeTab === 'schema'
                  ? 'border-emerald-500 text-emerald-400 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              schema.sql (SQLite3)
            </button>
            <button
              onClick={() => setActiveCodeTab('makefile')}
              className={`py-3 px-3 font-medium transition-colors border-b-2 ${
                activeCodeTab === 'makefile'
                  ? 'border-emerald-500 text-emerald-400 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Makefile
            </button>
            <button
              onClick={() => setActiveCodeTab('spec')}
              className={`py-3 px-3 font-medium transition-colors border-b-2 ${
                activeCodeTab === 'spec'
                  ? 'border-emerald-500 text-emerald-400 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              API Specification
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              const code =
                activeCodeTab === 'main'
                  ? cppMainCode
                  : activeCodeTab === 'schema'
                  ? schemaSql
                  : activeCodeTab === 'makefile'
                  ? makefileCode
                  : specMarkdown;
              copyCode(code, activeCodeTab);
            }}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-md transition-colors"
          >
            {copiedTab === activeCodeTab ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Code</span>
              </>
            )}
          </button>
        </div>

        {/* Code Content */}
        <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto max-h-[460px]">
          <pre>
            {activeCodeTab === 'main' && cppMainCode}
            {activeCodeTab === 'schema' && schemaSql}
            {activeCodeTab === 'makefile' && makefileCode}
            {activeCodeTab === 'spec' && specMarkdown}
          </pre>
        </div>
      </div>
    </div>
  );
};
