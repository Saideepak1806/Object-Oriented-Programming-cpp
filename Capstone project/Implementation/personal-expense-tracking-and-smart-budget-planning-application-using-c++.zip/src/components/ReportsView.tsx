import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  PieChart,
  BarChart3,
  Calendar,
  Printer,
  Inbox,
} from 'lucide-react';
import {
  Chart,
  ArcElement,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  DoughnutController,
  BarController,
} from 'chart.js';
import { Transaction } from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { formatINR } from '../utils/currency';

interface ReportsViewProps {
  transactions: Transaction[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ transactions }) => {
  // Discover all months available strictly from user's recorded transactions
  const availableMonths = useMemo(() => {
    const monthMap = new Map<string, string>();
    const currentMonth = new Date().toISOString().substring(0, 7);
    monthMap.set(currentMonth, 'Current Month');

    transactions.forEach((tx) => {
      if (tx.date && tx.date.length >= 7) {
        const m = tx.date.substring(0, 7);
        if (!monthMap.has(m)) {
          const parts = m.split('-');
          const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 1);
          monthMap.set(m, d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' }));
        }
      }
    });

    const list = Array.from(monthMap.entries()).map(([id, label]) => ({ id, label }));
    list.sort((a, b) => b.id.localeCompare(a.id));
    return [...list, { id: 'ALL', label: 'All-Time Aggregate' }];
  }, [transactions]);

  const [selectedMonth, setSelectedMonth] = useState<string>(
    availableMonths[0]?.id || new Date().toISOString().substring(0, 7)
  );

  const reportDoughnutRef = useRef<HTMLCanvasElement | null>(null);
  const reportBarRef = useRef<HTMLCanvasElement | null>(null);
  const doughnutChart = useRef<Chart | null>(null);
  const barChart = useRef<Chart | null>(null);

  // Filter transactions for report month
  const reportTransactions = transactions.filter((tx) => {
    if (selectedMonth === 'ALL') return true;
    return tx.date.startsWith(selectedMonth);
  });

  const totalIncome = reportTransactions
    .filter((tx) => tx.type === 'income')
    .reduce((acc, tx) => acc + tx.amount, 0);

  const totalExpense = reportTransactions
    .filter((tx) => tx.type === 'expense')
    .reduce((acc, tx) => acc + tx.amount, 0);

  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0;

  // Category breakdown for selected month
  const categoryData = EXPENSE_CATEGORIES.map((cat) => {
    const matching = reportTransactions.filter(
      (tx) => tx.type === 'expense' && tx.category === cat.id
    );
    const total = matching.reduce((acc, tx) => acc + tx.amount, 0);
    const count = matching.length;
    const avg = count > 0 ? total / count : 0;
    const share = totalExpense > 0 ? (total / totalExpense) * 100 : 0;

    return {
      category: cat.id,
      name: cat.name,
      color: cat.color,
      total,
      count,
      avg,
      share,
    };
  }).sort((a, b) => b.total - a.total);

  const topCategory = categoryData[0]?.total > 0 ? categoryData[0] : null;
  const hasExpenses = totalExpense > 0;
  const hasAnyTransactions = transactions.length > 0;

  // 1. Doughnut Chart for Category Breakdown
  useEffect(() => {
    if (!reportDoughnutRef.current) return;
    if (doughnutChart.current) {
      doughnutChart.current.destroy();
      doughnutChart.current = null;
    }

    if (!hasExpenses) return;

    const activeCats = categoryData.filter((c) => c.total > 0);
    if (activeCats.length === 0) return;

    const labels = activeCats.map((c) => c.name);
    const data = activeCats.map((c) => c.total);
    const backgroundColor = activeCats.map((c) => c.color);

    const ctx = reportDoughnutRef.current.getContext('2d');
    if (!ctx) return;

    doughnutChart.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          {
            data,
            backgroundColor,
            borderColor: '#0f172a',
            borderWidth: 2,
            hoverOffset: 6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: {
            position: 'right',
            labels: {
              boxWidth: 10,
              padding: 12,
              color: '#94a3b8',
              font: {
                size: 11,
                family: "'Plus Jakarta Sans', sans-serif",
              },
            },
          },
          tooltip: {
            backgroundColor: '#090d16',
            borderColor: '#334155',
            borderWidth: 1,
            titleColor: '#f8fafc',
            bodyColor: '#cbd5e1',
            padding: 10,
            callbacks: {
              label: (ctx) => {
                const val = ctx.parsed;
                const pct = totalExpense > 0 ? ((val / totalExpense) * 100).toFixed(1) : '0';
                return ` ${formatINR(val)} (${pct}%)`;
              },
            },
          },
        },
      },
    });

    return () => {
      if (doughnutChart.current) doughnutChart.current.destroy();
    };
  }, [categoryData, totalExpense, hasExpenses]);

  // 2. Bar Chart for Monthly Expense Comparison
  useEffect(() => {
    if (!reportBarRef.current) return;
    if (barChart.current) {
      barChart.current.destroy();
      barChart.current = null;
    }

    if (!hasAnyTransactions) return;

    // Distinct months from transactions
    const monthSet = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.date && tx.date.length >= 7) {
        monthSet.add(tx.date.substring(0, 7));
      }
    });

    const months = Array.from(monthSet).sort().slice(-6); // last 6 active months
    if (months.length === 0) return;

    const labels = months.map((m) => {
      const parts = m.split('-');
      const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 1);
      return d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
    });

    const incomeSeries = months.map((m) =>
      transactions
        .filter((tx) => tx.date.startsWith(m) && tx.type === 'income')
        .reduce((sum, tx) => sum + tx.amount, 0)
    );

    const expenseSeries = months.map((m) =>
      transactions
        .filter((tx) => tx.date.startsWith(m) && tx.type === 'expense')
        .reduce((sum, tx) => sum + tx.amount, 0)
    );

    const savingsSeries = incomeSeries.map((inc, i) => inc - expenseSeries[i]);

    const ctx = reportBarRef.current.getContext('2d');
    if (!ctx) return;

    barChart.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Total Inflow (Income)',
            data: incomeSeries,
            backgroundColor: 'rgba(16, 185, 129, 0.75)',
            borderColor: '#10b981',
            borderWidth: 1,
            borderRadius: 4,
          },
          {
            label: 'Total Outflow (Expenses)',
            data: expenseSeries,
            backgroundColor: 'rgba(239, 68, 68, 0.75)',
            borderColor: '#ef4444',
            borderWidth: 1,
            borderRadius: 4,
          },
          {
            label: 'Net Savings',
            data: savingsSeries,
            backgroundColor: 'rgba(59, 130, 246, 0.75)',
            borderColor: '#3b82f6',
            borderWidth: 1,
            borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 10,
              padding: 10,
              color: '#94a3b8',
              font: { size: 11 },
            },
          },
          tooltip: {
            backgroundColor: '#090d16',
            borderColor: '#334155',
            borderWidth: 1,
            callbacks: {
              label: (ctx) => ` ${ctx.dataset.label}: ${formatINR(ctx.parsed.y ?? 0)}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: 'rgba(51, 65, 85, 0.25)' },
            ticks: { color: '#94a3b8', font: { size: 11 } },
          },
          y: {
            grid: { color: 'rgba(51, 65, 85, 0.25)' },
            ticks: {
              color: '#94a3b8',
              font: { size: 11 },
              callback: (v) => `₹${v}`,
            },
          },
        },
      },
    });

    return () => {
      if (barChart.current) barChart.current.destroy();
    };
  }, [transactions, hasAnyTransactions]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Title & Month Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Financial Summaries & Spending Reports
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Module 4: Historical comparisons, category breakdowns, and savings performance (₹ INR)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Month Selector dropdown */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-emerald-400" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-hidden font-medium"
            >
              {availableMonths.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-white">
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-850 transition-colors"
            title="Print or Save PDF report"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs font-medium text-slate-400">Total Income</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {formatINR(totalIncome)}
          </div>
          <div className="text-[11px] text-emerald-400 font-mono">
            {reportTransactions.filter((t) => t.type === 'income').length} recorded entries
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs font-medium text-slate-400">Total Expenses</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {formatINR(totalExpense)}
          </div>
          <div className="text-[11px] text-rose-400 font-mono">
            {reportTransactions.filter((t) => t.type === 'expense').length} recorded entries
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs font-medium text-slate-400">Net Savings</div>
          <div
            className={`text-2xl font-bold font-mono tabular-nums ${
              netSavings >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {formatINR(netSavings, true)}
          </div>
          <div className="text-[11px] text-slate-400">
            {netSavings >= 0 ? 'Net surplus' : 'Net deficit'}
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs font-medium text-slate-400">Savings Rate</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {savingsRate.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            {totalIncome > 0 ? (savingsRate >= 20 ? 'Target achieved (≥20%)' : 'Below 20% target') : 'No income recorded'}
          </div>
        </div>
      </div>

      {/* Visual Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Doughnut Chart */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-white">Expense Distribution by Category</h2>
              <p className="text-xs text-slate-400">Proportional spending for selected timeframe</p>
            </div>
            {topCategory && (
              <span className="text-xs font-mono text-slate-400">
                Top: <strong className="text-white">{topCategory.name}</strong> ({topCategory.share.toFixed(1)}%)
              </span>
            )}
          </div>
          <div className="relative flex-1 min-h-[280px] flex items-center justify-center">
            {hasExpenses ? (
              <canvas ref={reportDoughnutRef} />
            ) : (
              <div className="text-center p-6 space-y-2">
                <PieChart className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs font-medium text-slate-300">
                  No expense records in this timeframe
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Category proportion doughnut will display once expenses are recorded for {selectedMonth}.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Bar Chart */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-white">Monthly Cashflow Comparisons</h2>
              <p className="text-xs text-slate-400">Multi-month Income vs Outflow vs Net Savings</p>
            </div>
            <span className="text-[11px] font-mono text-slate-400">Recorded Months</span>
          </div>
          <div className="relative flex-1 min-h-[280px] flex items-center justify-center">
            {hasAnyTransactions ? (
              <canvas ref={reportBarRef} />
            ) : (
              <div className="text-center p-6 space-y-2">
                <BarChart3 className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs font-medium text-slate-300">
                  No monthly comparison data yet
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Add transactions across months to generate visual cashflow bars.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Category Breakdown Table */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">
            Category Breakdown Ledger
          </h2>
          <span className="text-xs font-mono text-slate-400">
            Total Outflow: {formatINR(totalExpense)}
          </span>
        </div>

        {hasExpenses ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3 text-right">Transactions</th>
                  <th className="py-2.5 px-3 text-right">Avg Cost / Tx</th>
                  <th className="py-2.5 px-3 text-right">% of Total</th>
                  <th className="py-2.5 px-3 text-right">Total Outflow</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {categoryData.map((cat) => (
                  <tr key={cat.category} className="hover:bg-slate-850/50 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                        <span className="font-medium text-slate-200">{cat.name}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-300">
                      {cat.count}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-300">
                      {formatINR(cat.avg)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-400">
                      {cat.share.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-white tabular-nums">
                      {formatINR(cat.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-8 text-center text-slate-400">
            <p className="text-xs">No expense transactions recorded for the selected period.</p>
          </div>
        )}
      </div>
    </div>
  );
};
