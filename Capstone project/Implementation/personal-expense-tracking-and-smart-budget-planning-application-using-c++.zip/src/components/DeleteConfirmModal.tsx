import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { Transaction } from '../types';
import { formatINR } from '../utils/currency';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  transaction: Transaction | null;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  transaction,
}) => {
  if (!isOpen || !transaction) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-4">
          <div className="p-3 bg-rose-950/70 text-rose-400 border border-rose-800/60 rounded-xl shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-semibold text-white">Delete Transaction</h3>
            <p className="text-xs text-slate-400 mt-1">
              Are you sure you want to remove this transaction? This action will permanently update your balance, budget calculations, and financial reports.
            </p>

            <div className="my-4 p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Description:</span>
                <span className="font-medium truncate max-w-[200px]">{transaction.description}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Category / Date:</span>
                <span>{transaction.category} · {transaction.date}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500">Amount:</span>
                <span className={`font-mono font-semibold ${transaction.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {formatINR(transaction.amount, true)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 mt-5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
                Delete Transaction
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
