import React, { useState, useEffect } from 'react';
import { X, Check, Sliders } from 'lucide-react';
import { BudgetConfig, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { formatINR } from '../utils/currency';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBudget: BudgetConfig;
  onSave: (newBudget: BudgetConfig) => void;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  currentBudget,
  onSave,
}) => {
  const [overallLimit, setOverallLimit] = useState<string>('');
  const [categories, setCategories] = useState<Record<ExpenseCategory, string>>({
    Food: '',
    Transport: '',
    Education: '',
    Shopping: '',
    Entertainment: '',
    Healthcare: '',
    Others: '',
  });

  useEffect(() => {
    if (currentBudget) {
      setOverallLimit(currentBudget.overallLimit > 0 ? currentBudget.overallLimit.toString() : '');
      const catState: Record<ExpenseCategory, string> = {
        Food: (currentBudget.categories.Food || 0) > 0 ? currentBudget.categories.Food.toString() : '',
        Transport: (currentBudget.categories.Transport || 0) > 0 ? currentBudget.categories.Transport.toString() : '',
        Education: (currentBudget.categories.Education || 0) > 0 ? currentBudget.categories.Education.toString() : '',
        Shopping: (currentBudget.categories.Shopping || 0) > 0 ? currentBudget.categories.Shopping.toString() : '',
        Entertainment: (currentBudget.categories.Entertainment || 0) > 0 ? currentBudget.categories.Entertainment.toString() : '',
        Healthcare: (currentBudget.categories.Healthcare || 0) > 0 ? currentBudget.categories.Healthcare.toString() : '',
        Others: (currentBudget.categories.Others || 0) > 0 ? currentBudget.categories.Others.toString() : '',
      };
      setCategories(catState);
    }
  }, [currentBudget, isOpen]);

  if (!isOpen) return null;

  const handleCategoryChange = (cat: ExpenseCategory, val: string) => {
    setCategories((prev) => ({
      ...prev,
      [cat]: val,
    }));
  };

  const calculateSum = () => {
    return Object.values(categories).reduce((acc, curr) => {
      const num = parseFloat(curr) || 0;
      return acc + num;
    }, 0);
  };

  const handleAutoSumOverall = () => {
    setOverallLimit(calculateSum().toString());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedOverall = parseFloat(overallLimit) || calculateSum();
    const parsedCategories: Record<ExpenseCategory, number> = {
      Food: parseFloat(categories.Food) || 0,
      Transport: parseFloat(categories.Transport) || 0,
      Education: parseFloat(categories.Education) || 0,
      Shopping: parseFloat(categories.Shopping) || 0,
      Entertainment: parseFloat(categories.Entertainment) || 0,
      Healthcare: parseFloat(categories.Healthcare) || 0,
      Others: parseFloat(categories.Others) || 0,
    };

    onSave({
      month: currentBudget.month,
      overallLimit: parsedOverall,
      categories: parsedCategories,
    });
    onClose();
  };

  const totalAllocated = calculateSum();
  const overallLimitNum = parseFloat(overallLimit) || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-950/60 text-emerald-400 border border-emerald-800/60 rounded-lg">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Set Monthly Budget Limits</h3>
              <p className="text-xs text-slate-400">Define user spending targets for {currentBudget.month} in ₹ INR</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Overall Monthly Budget */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-white">
                Total Monthly Budget Cap (₹ INR)
              </label>
              <button
                type="button"
                onClick={handleAutoSumOverall}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 transition-colors font-medium"
              >
                Auto-match Category Sum ({formatINR(totalAllocated)})
              </button>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-sm font-semibold text-slate-400 font-mono">₹</span>
              <input
                type="number"
                min="0"
                step="50"
                placeholder="Enter monthly cap (e.g. 50000)"
                value={overallLimit}
                onChange={(e) => setOverallLimit(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white font-mono focus:outline-hidden focus:border-emerald-500"
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Category Sum: <span className="font-mono text-slate-200">{formatINR(totalAllocated)}</span></span>
              <span>
                Difference: <span className={`font-mono ${overallLimitNum >= totalAllocated ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {formatINR(overallLimitNum - totalAllocated)}
                </span>
              </span>
            </div>
          </div>

          {/* Category-wise Budgets */}
          <div>
            <h4 className="text-xs font-medium text-slate-400 mb-3">Category-wise Limits (₹ INR)</h4>
            <div className="space-y-2.5">
              {EXPENSE_CATEGORIES.map((cat) => (
                <div key={cat.id} className="flex items-center justify-between gap-3 p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-lg">
                  <div className="flex items-center gap-2">
                    <span 
                      className="w-2.5 h-2.5 rounded-full shrink-0" 
                      style={{ backgroundColor: cat.color }} 
                    />
                    <span className="text-xs font-medium text-slate-200">{cat.name}</span>
                  </div>
                  <div className="relative w-36 shrink-0">
                    <span className="absolute left-2.5 top-1.5 text-xs text-slate-400 font-mono">₹</span>
                    <input
                      type="number"
                      min="0"
                      step="50"
                      placeholder="0.00"
                      value={categories[cat.id]}
                      onChange={(e) => handleCategoryChange(cat.id, e.target.value)}
                      className="w-full pl-6 pr-2 py-1 bg-slate-900 border border-slate-800 rounded-md text-xs text-white font-mono text-right focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
            >
              <Check className="w-4 h-4" />
              Save Budget Limits
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
