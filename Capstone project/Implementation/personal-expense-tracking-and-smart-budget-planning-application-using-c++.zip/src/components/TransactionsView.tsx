import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  Download,
  Trash2,
  Edit2,
  ArrowUpDown,
  Calendar,
  X,
  Inbox,
} from 'lucide-react';
import { Transaction, TransactionType, Category, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { formatINR } from '../utils/currency';

interface TransactionsViewProps {
  transactions: Transaction[];
  onOpenAddModal: () => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (tx: Transaction) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  onOpenAddModal,
  onEditTransaction,
  onDeleteTransaction,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');

  // Filtered & Sorted Transactions
  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        // Search query matching description, category, notes, or amount
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchDesc = tx.description.toLowerCase().includes(q);
          const matchCat = tx.category.toLowerCase().includes(q);
          const matchNotes = tx.notes ? tx.notes.toLowerCase().includes(q) : false;
          const matchAmount = tx.amount.toString().includes(q);
          if (!matchDesc && !matchCat && !matchNotes && !matchAmount) {
            return false;
          }
        }

        // Category filter
        if (selectedCategory !== 'ALL' && tx.category !== selectedCategory) {
          return false;
        }

        // Type filter (All, expense, income)
        if (selectedType !== 'ALL' && tx.type !== selectedType) {
          return false;
        }

        // Date range
        if (startDate && tx.date < startDate) {
          return false;
        }
        if (endDate && tx.date > endDate) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return b.date.localeCompare(a.date);
        if (sortBy === 'date_asc') return a.date.localeCompare(b.date);
        if (sortBy === 'amount_desc') return b.amount - a.amount;
        if (sortBy === 'amount_asc') return a.amount - b.amount;
        return 0;
      });
  }, [transactions, searchQuery, selectedCategory, selectedType, startDate, endDate, sortBy]);

  // Calculations on filtered set
  const filteredIncome = filteredTransactions
    .filter((tx) => tx.type === 'income')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const filteredExpense = filteredTransactions
    .filter((tx) => tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);

  // Clear filters
  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('ALL');
    setSelectedType('ALL');
    setStartDate('');
    setEndDate('');
    setSortBy('date_desc');
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedCategory !== 'ALL' ||
    selectedType !== 'ALL' ||
    startDate !== '' ||
    endDate !== '';

  // Export to CSV with ₹ INR amounts
  const handleExportCSV = () => {
    const headers = ['ID', 'Type', 'Category', 'Description', 'Amount (INR)', 'Date', 'PaymentMethod', 'Notes'];
    const rows = filteredTransactions.map((tx) => [
      tx.id,
      tx.type,
      `"${tx.category}"`,
      `"${tx.description.replace(/"/g, '""')}"`,
      tx.amount.toFixed(2),
      tx.date,
      `"${tx.paymentMethod}"`,
      `"${(tx.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_inr_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Transaction Ledger & Search
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Module 1 & 2: Categorization, multi-parameter search, and instant recalculation (₹ INR)
          </p>
        </div>

        <div className="flex items-center gap-2">
          {transactions.length > 0 && (
            <button
              type="button"
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-850 transition-colors"
              title="Download CSV of current filtered list"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Export CSV</span>
            </button>
          )}
          <button
            type="button"
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by description, notes, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-emerald-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-500 hover:text-slate-300"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="md:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-hidden focus:border-emerald-500"
            >
              <option value="ALL">All Categories</option>
              <optgroup label="Expense Categories">
                {EXPENSE_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Income Categories">
                <option value="Salary">Salary</option>
                <option value="Freelance">Freelance</option>
                <option value="Investments">Investments</option>
                <option value="Grants & Scholarships">Grants & Scholarships</option>
                <option value="Other Income">Other Income</option>
              </optgroup>
            </select>
          </div>

          {/* Type Segmented Buttons */}
          <div className="md:col-span-4 flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg">
            {(['ALL', 'expense', 'income'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setSelectedType(t)}
                className={`flex-1 py-1 px-2 text-[11px] font-medium rounded-md transition-all ${
                  selectedType === t
                    ? 'bg-slate-800 text-white shadow-xs font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t === 'ALL' ? 'All Types' : t === 'expense' ? 'Expenses' : 'Income'}
              </button>
            ))}
          </div>
        </div>

        {/* Date Filter & Sort Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/60 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-400 text-[11px] flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>Date:</span>
            </span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2 py-1 bg-slate-950 border border-slate-800 rounded-md text-[11px] text-white focus:outline-hidden focus:border-emerald-500"
            />
            <span className="text-slate-500">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2 py-1 bg-slate-950 border border-slate-800 rounded-md text-[11px] text-white focus:outline-hidden focus:border-emerald-500"
            />

            {hasActiveFilters && (
              <button
                type="button"
                onClick={handleClearFilters}
                className="text-[11px] text-rose-400 hover:text-rose-300 ml-2 font-medium"
              >
                Reset Filters
              </button>
            )}
          </div>

          {/* Sort selection */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px] flex items-center gap-1">
              <ArrowUpDown className="w-3 h-3" />
              <span>Sort:</span>
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2 py-1 bg-slate-950 border border-slate-800 rounded-md text-[11px] text-white focus:outline-hidden focus:border-emerald-500"
            >
              <option value="date_desc">Date (Newest first)</option>
              <option value="date_asc">Date (Oldest first)</option>
              <option value="amount_desc">Amount (Highest first)</option>
              <option value="amount_asc">Amount (Lowest first)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Filtered Aggregation Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between">
          <span className="text-xs text-slate-400">Matching Records</span>
          <span className="font-mono text-xs font-semibold text-white">
            {filteredTransactions.length} of {transactions.length}
          </span>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between">
          <span className="text-xs text-slate-400">Total Filtered Income</span>
          <span className="font-mono text-xs font-semibold text-emerald-400">
            {formatINR(filteredIncome, true)}
          </span>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between">
          <span className="text-xs text-slate-400">Total Filtered Outflow</span>
          <span className="font-mono text-xs font-semibold text-rose-400">
            {formatINR(-filteredExpense)}
          </span>
        </div>
      </div>

      {/* Main Table for Laptop/Desktop + Card List for Mobile */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {/* Desktop Data Grid */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Method</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <div className="space-y-2 max-w-sm mx-auto">
                      <Inbox className="w-8 h-8 text-slate-600 mx-auto" />
                      <p className="text-sm font-medium text-slate-300">
                        {transactions.length === 0
                          ? 'No transactions yet. Add your first transaction.'
                          : 'No transactions match the selected filters.'}
                      </p>
                      <p className="text-xs text-slate-500">
                        {transactions.length === 0
                          ? 'Manually record your income and expenses to track your balance and budget.'
                          : 'Try clearing your filters or search keywords.'}
                      </p>
                      <button
                        type="button"
                        onClick={transactions.length === 0 ? onOpenAddModal : handleClearFilters}
                        className="mt-2 inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
                      >
                        {transactions.length === 0 ? (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add Your First Transaction</span>
                          </>
                        ) : (
                          <span>Reset Filters</span>
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    className="hover:bg-slate-850/60 transition-colors group"
                  >
                    <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                      {tx.date}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{
                            backgroundColor:
                              tx.type === 'expense'
                                ? EXPENSE_CATEGORIES.find((c) => c.id === tx.category)?.color || '#94a3b8'
                                : '#10b981',
                          }}
                        />
                        <span className="text-slate-200 font-medium">{tx.category}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-white">{tx.description}</div>
                      {tx.notes && (
                        <div className="text-[11px] text-slate-400 mt-0.5">{tx.notes}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      {tx.paymentMethod}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold whitespace-nowrap tabular-nums">
                      <span
                        className={
                          tx.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'
                        }
                      >
                        {formatINR(tx.amount, true)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onEditTransaction(tx)}
                          className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
                          title="Edit transaction"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteTransaction(tx)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 rounded-md hover:bg-slate-800 transition-colors"
                          title="Delete transaction"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile View Card List */}
        <div className="block md:hidden divide-y divide-slate-800/60 p-2">
          {filteredTransactions.length === 0 ? (
            <div className="py-8 text-center text-slate-400 space-y-2">
              <p className="text-xs font-medium text-slate-300">
                {transactions.length === 0
                  ? 'No transactions yet. Add your first transaction.'
                  : 'No matching transactions.'}
              </p>
              <button
                type="button"
                onClick={transactions.length === 0 ? onOpenAddModal : handleClearFilters}
                className="px-3 py-1.5 text-xs text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md font-semibold"
              >
                {transactions.length === 0 ? 'Add Transaction' : 'Clear Filters'}
              </button>
            </div>
          ) : (
            filteredTransactions.map((tx) => (
              <div key={tx.id} className="p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white truncate">{tx.description}</div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                      <span>{tx.category}</span>
                      <span>·</span>
                      <span className="font-mono">{tx.date}</span>
                      <span>·</span>
                      <span>{tx.paymentMethod}</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span
                      className={`font-mono text-xs font-bold tabular-nums ${
                        tx.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {formatINR(tx.amount, true)}
                    </span>
                  </div>
                </div>

                {tx.notes && (
                  <div className="text-[11px] text-slate-400 bg-slate-950 p-1.5 rounded-md">
                    {tx.notes}
                  </div>
                )}

                <div className="flex items-center justify-end gap-3 pt-1 text-xs">
                  <button
                    type="button"
                    onClick={() => onEditTransaction(tx)}
                    className="text-slate-400 hover:text-white"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteTransaction(tx)}
                    className="text-rose-400 hover:text-rose-300"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Footer count indicator */}
      <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
        <span>Showing {filteredTransactions.length} of {transactions.length} total entries</span>
        <span className="text-slate-500">Currency: Indian Rupee (₹ INR)</span>
      </div>
    </div>
  );
};
