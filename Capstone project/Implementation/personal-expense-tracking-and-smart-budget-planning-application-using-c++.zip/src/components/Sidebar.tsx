import React from 'react';
import {
  LayoutDashboard,
  ReceiptText,
  PiggyBank,
  PieChart,
  Terminal,
  User,
  Sliders,
  ChevronRight,
  Database,
  X,
  LogOut,
} from 'lucide-react';
import { UserAccount, BackendStatus } from '../types';
import { formatINR } from '../utils/currency';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  currentUser: UserAccount;
  backendStatus: BackendStatus;
  monthlySpent: number;
  overallBudget: number;
  onOpenProfileModal: () => void;
  onOpenBudgetModal: () => void;
  onLogout: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  backendStatus,
  monthlySpent,
  overallBudget,
  onOpenProfileModal,
  onOpenBudgetModal,
  onLogout,
  isMobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Overview & recent activity',
    },
    {
      id: 'transactions',
      label: 'Transactions',
      icon: ReceiptText,
      description: 'Records, filters & search',
    },
    {
      id: 'budget',
      label: 'Budget & Alerts',
      icon: PiggyBank,
      description: 'Limits & overspending alerts',
    },
    {
      id: 'reports',
      label: 'Spending Reports',
      icon: PieChart,
      description: 'Monthly breakdowns & charts',
    },
    {
      id: 'cpp_backend',
      label: 'C++ Backend Hub',
      icon: Terminal,
      description: 'cpp-httplib & SQLite3 spec',
    },
  ];

  const hasBudgetSet = overallBudget > 0;
  const budgetUsagePercent = hasBudgetSet ? (monthlySpent / overallBudget) * 100 : 0;
  const isBudgetExceeded = hasBudgetSet && budgetUsagePercent > 100;
  const isBudgetWarning = hasBudgetSet && budgetUsagePercent >= 80 && !isBudgetExceeded;

  const content = (
    <div className="flex flex-col h-full bg-slate-950 border-r border-slate-800/80 p-4">
      {/* Mobile close bar */}
      <div className="flex items-center justify-between md:hidden pb-3 border-b border-slate-800 mb-3">
        <span className="text-sm font-bold text-white">SmartBudget C++</span>
        <button
          onClick={onCloseMobile}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Nav List */}
      <div className="space-y-1 flex-1">
        <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectTab(item.id);
                onCloseMobile();
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all ${
                isActive
                  ? 'bg-slate-900 text-white font-medium border border-slate-800 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive ? 'text-emerald-400' : 'text-slate-500'
                }`}
              />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold truncate leading-tight">{item.label}</div>
                <div className="text-[11px] text-slate-400 truncate">{item.description}</div>
              </div>
              {isActive && <ChevronRight className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
            </button>
          );
        })}
      </div>

      {/* Monthly Budget Gauge Mini Widget (Strictly user-controlled) */}
      <div className="my-4 p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-medium text-slate-300">Monthly Budget</span>
          <button
            type="button"
            onClick={onOpenBudgetModal}
            className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            <Sliders className="w-3 h-3" />
            <span>{hasBudgetSet ? 'Adjust' : 'Set Limit'}</span>
          </button>
        </div>

        {hasBudgetSet ? (
          <>
            <div className="flex items-baseline justify-between font-mono text-xs">
              <span className="text-white font-semibold tabular-nums">
                {formatINR(monthlySpent)}
              </span>
              <span className="text-slate-400 tabular-nums">
                of {formatINR(overallBudget)}
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800/80">
              <div
                className={`h-full transition-all duration-300 rounded-full ${
                  isBudgetExceeded
                    ? 'bg-rose-500'
                    : isBudgetWarning
                    ? 'bg-amber-400'
                    : 'bg-emerald-400'
                }`}
                style={{ width: `${Math.min(budgetUsagePercent, 100)}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1">
              <span
                className={`font-mono font-medium ${
                  isBudgetExceeded
                    ? 'text-rose-400'
                    : isBudgetWarning
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {budgetUsagePercent.toFixed(1)}% utilized
              </span>
              <span className="text-slate-400">
                {isBudgetExceeded
                  ? 'Exceeded'
                  : isBudgetWarning
                  ? 'Warning ≥80%'
                  : 'On Track'}
              </span>
            </div>
          </>
        ) : (
          <div className="py-1 text-[11px] text-slate-400 space-y-1">
            <p>No budget set yet for this month.</p>
            <p className="text-emerald-400 font-mono text-[10px]">
              Spending: {formatINR(monthlySpent)}
            </p>
          </div>
        )}
      </div>

      {/* Backend Engine Status Banner */}
      <div
        onClick={() => {
          onSelectTab('cpp_backend');
          onCloseMobile();
        }}
        className="mb-4 p-2.5 bg-slate-900/60 border border-slate-800/80 rounded-lg cursor-pointer hover:border-slate-700 transition-all text-xs"
      >
        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
          <span className="flex items-center gap-1.5 font-medium text-slate-300">
            <Database className="w-3.5 h-3.5 text-blue-400" />
            <span>Backend Architecture</span>
          </span>
          <span className="font-mono text-[10px] text-slate-400">C++17 SQLite</span>
        </div>
        <div className="text-[11px] text-slate-400 flex items-center justify-between">
          <span>{backendStatus.mode === 'cpp_server' ? 'Server: 8080' : 'Local Prototype Storage'}</span>
          <span
            className={`text-[10px] font-mono ${
              backendStatus.isOnline ? 'text-emerald-400' : 'text-slate-400'
            }`}
          >
            {backendStatus.isOnline ? 'ONLINE' : 'ACTIVE'}
          </span>
        </div>
      </div>

      {/* Active User Card & Logout Option */}
      <div className="space-y-2">
        <div
          onClick={onOpenProfileModal}
          className="p-2.5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-colors flex items-center gap-2.5"
        >
          <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-700/60 flex items-center justify-center text-emerald-300 font-bold text-xs shrink-0">
            {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-white truncate">{currentUser.name}</div>
            <div className="text-[11px] text-slate-400 truncate">{currentUser.email}</div>
          </div>
          <User className="w-4 h-4 text-slate-500 shrink-0" />
        </div>

        <button
          type="button"
          onClick={() => {
            onLogout();
            onCloseMobile();
          }}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-medium text-slate-400 hover:text-rose-300 bg-slate-900/80 hover:bg-rose-950/40 border border-slate-800 hover:border-rose-900/60 rounded-lg transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out / Logout</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop static sidebar */}
      <aside className="hidden md:block w-64 shrink-0 min-h-[calc(100vh-57px)]">
        {content}
      </aside>

      {/* Mobile drawer backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        >
          <div
            className="w-72 max-w-[85vw] h-full shadow-2xl animate-in slide-in-from-left duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {content}
          </div>
        </div>
      )}
    </>
  );
};
