import React from 'react';
import {
  Sliders,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  TrendingDown,
  Calendar,
  Sparkles,
  PieChart,
  Plus,
} from 'lucide-react';
import { BudgetConfig, Transaction, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { formatINR } from '../utils/currency';

interface BudgetViewProps {
  budgetConfig: BudgetConfig;
  transactions: Transaction[];
  onOpenBudgetModal: () => void;
  onOpenAddModal: () => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({
  budgetConfig,
  transactions,
  onOpenBudgetModal,
  onOpenAddModal,
}) => {
  // Current month transactions (e.g. 2026-11)
  const currentMonthTransactions = transactions.filter(
    (tx) => tx.date.startsWith(budgetConfig.month) && tx.type === 'expense'
  );

  const totalExpense = currentMonthTransactions.reduce((acc, tx) => acc + tx.amount, 0);
  const hasBudgetSet = budgetConfig.overallLimit > 0;
  const overallLimit = hasBudgetSet ? budgetConfig.overallLimit : 0;
  const overallPercent = hasBudgetSet ? (totalExpense / overallLimit) * 100 : 0;
  const overallRemaining = overallLimit - totalExpense;

  // Calendar day calculation
  const now = new Date();
  const currentDay = now.getDate();
  const totalDaysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysRemaining = Math.max(1, totalDaysInMonth - currentDay);
  const averageDailySpend = currentDay > 0 ? totalExpense / currentDay : 0;
  const recommendedDailyCap =
    hasBudgetSet && overallRemaining > 0 ? overallRemaining / daysRemaining : 0;

  // Category expenses map from user transactions
  const categoryExpenses: Record<ExpenseCategory, number> = {
    Food: 0,
    Transport: 0,
    Education: 0,
    Shopping: 0,
    Entertainment: 0,
    Healthcare: 0,
    Others: 0,
  };

  currentMonthTransactions.forEach((tx) => {
    const cat = tx.category as ExpenseCategory;
    if (categoryExpenses[cat] !== undefined) {
      categoryExpenses[cat] += tx.amount;
    } else {
      categoryExpenses.Others += tx.amount;
    }
  });

  // Calculate alerts list
  const categoryAlerts = EXPENSE_CATEGORIES.map((cat) => {
    const spent = categoryExpenses[cat.id] || 0;
    const limit = budgetConfig.categories[cat.id] || 0;
    const hasCatLimit = limit > 0;
    const percent = hasCatLimit ? (spent / limit) * 100 : 0;
    const remaining = limit - spent;
    let status: 'unset' | 'normal' | 'warning' | 'exceeded' = 'unset';

    if (hasCatLimit) {
      if (percent > 100) {
        status = 'exceeded';
      } else if (percent >= 80) {
        status = 'warning';
      } else {
        status = 'normal';
      }
    }

    return {
      category: cat.id,
      name: cat.name,
      color: cat.color,
      spent,
      limit,
      hasCatLimit,
      percent,
      remaining,
      status,
    };
  });

  const exceededCount = categoryAlerts.filter((a) => a.status === 'exceeded').length;
  const warningCount = categoryAlerts.filter((a) => a.status === 'warning').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Budget Planning & Overspending Alerts
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Module 3: Proactive spending thresholds, utilization monitoring, and smart budget limits (₹ INR)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onOpenBudgetModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
          >
            <Sliders className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{hasBudgetSet ? 'Modify Budget Caps' : 'Set Monthly Budget'}</span>
          </button>
        </div>
      </div>

      {/* Main Overall Monthly Budget Card */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Overall Monthly Budget ({budgetConfig.month})
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-bold font-mono text-white tabular-nums">
                {formatINR(totalExpense)}
              </span>
              <span className="text-sm font-mono text-slate-400">
                {hasBudgetSet ? `spent of ${formatINR(overallLimit)} target` : 'spent (no cap configured)'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-right">
              <div className="text-[11px] text-slate-400">Remaining Cushion</div>
              <div
                className={`font-mono text-base font-bold tabular-nums ${
                  !hasBudgetSet
                    ? 'text-slate-400'
                    : overallRemaining >= 0
                    ? 'text-emerald-400'
                    : 'text-rose-400'
                }`}
              >
                {hasBudgetSet ? formatINR(overallRemaining, true) : 'Not Set'}
              </div>
            </div>
          </div>
        </div>

        {/* Big visual progress bar */}
        {hasBudgetSet ? (
          <div className="space-y-1.5">
            <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-300 rounded-full ${
                  overallPercent > 100
                    ? 'bg-rose-500'
                    : overallPercent >= 80
                    ? 'bg-amber-400'
                    : 'bg-emerald-400'
                }`}
                style={{ width: `${Math.min(overallPercent, 100)}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">{overallPercent.toFixed(1)}% utilized</span>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="text-[11px]">Normal (&lt;80%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="text-[11px]">Warning (80-100%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  <span className="text-[11px]">Exceeded (&gt;100%)</span>
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <span className="text-slate-400">
              You haven't set a budget ceiling for {budgetConfig.month} yet. Set a budget to track spending limits and receive automated alerts.
            </span>
            <button
              type="button"
              onClick={onOpenBudgetModal}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-md font-semibold shrink-0"
            >
              Set Monthly Limit
            </button>
          </div>
        )}

        {/* Daily Velocity & Smart Budget Guidance */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/80 text-xs">
          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-slate-400 text-[11px]">Average Daily Burn</div>
            <div className="font-mono text-sm font-semibold text-white mt-0.5 tabular-nums">
              {formatINR(averageDailySpend)} / day
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Based on {currentDay} days elapsed</div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-slate-400 text-[11px]">Recommended Daily Cap</div>
            <div className="font-mono text-sm font-semibold text-emerald-400 mt-0.5 tabular-nums">
              {hasBudgetSet ? `${formatINR(recommendedDailyCap)} / day` : 'Set budget first'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">For {daysRemaining} days remaining in month</div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-slate-400 text-[11px]">Alerts Status</div>
            <div className="font-mono text-sm font-semibold text-white mt-0.5">
              {!hasBudgetSet ? (
                <span className="text-slate-400">Budget Unset</span>
              ) : exceededCount > 0 ? (
                <span className="text-rose-400">{exceededCount} Exceeded</span>
              ) : warningCount > 0 ? (
                <span className="text-amber-400">{warningCount} Approaching</span>
              ) : (
                <span className="text-emerald-400">All Categories Nominal</span>
              )}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              {exceededCount + warningCount} active threshold notifications
            </div>
          </div>
        </div>
      </div>

      {/* Category-wise Budget Limits Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-white">
            Category-wise Budget Allocations & Utilization
          </h2>
          <button
            type="button"
            onClick={onOpenBudgetModal}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
          >
            Adjust Limits
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categoryAlerts.map((item) => (
            <div
              key={item.category}
              className={`p-4 bg-slate-900 border rounded-xl space-y-3 transition-colors ${
                item.status === 'exceeded'
                  ? 'border-rose-800/80 bg-rose-950/20'
                  : item.status === 'warning'
                  ? 'border-amber-800/70 bg-amber-950/15'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: item.color }}
                  />
                  <div>
                    <h3 className="text-xs font-semibold text-white">{item.name}</h3>
                    <div className="text-[11px] text-slate-400">
                      Limit: <span className="font-mono">{item.hasCatLimit ? formatINR(item.limit) : 'No limit set'}</span>
                    </div>
                  </div>
                </div>

                {/* Status Badges */}
                <div>
                  {item.status === 'exceeded' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm bg-rose-950/80 text-rose-300 border border-rose-800 text-[10px] font-semibold">
                      <AlertTriangle className="w-3 h-3" />
                      Exceeded ({formatINR(Math.abs(item.remaining))})
                    </span>
                  )}
                  {item.status === 'warning' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm bg-amber-950/80 text-amber-300 border border-amber-800 text-[10px] font-semibold">
                      <AlertCircle className="w-3 h-3" />
                      Warning (≥80%)
                    </span>
                  )}
                  {item.status === 'normal' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 text-[10px] font-medium">
                      <CheckCircle2 className="w-3 h-3" />
                      On Track
                    </span>
                  )}
                  {item.status === 'unset' && (
                    <span className="text-[10px] text-slate-500 font-mono">
                      No cap set
                    </span>
                  )}
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800/80">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      item.status === 'exceeded'
                        ? 'bg-rose-500'
                        : item.status === 'warning'
                        ? 'bg-amber-400'
                        : item.status === 'normal'
                        ? 'bg-emerald-400'
                        : 'bg-slate-700'
                    }`}
                    style={{ width: `${item.hasCatLimit ? Math.min(item.percent, 100) : 0}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-slate-300">
                    Spent: {formatINR(item.spent)} {item.hasCatLimit ? `(${item.percent.toFixed(1)}%)` : ''}
                  </span>
                  <span
                    className={
                      !item.hasCatLimit
                        ? 'text-slate-500'
                        : item.remaining >= 0
                        ? 'text-slate-400'
                        : 'text-rose-400 font-semibold'
                    }
                  >
                    {!item.hasCatLimit
                      ? 'No limit'
                      : item.remaining >= 0
                      ? `${formatINR(item.remaining)} left`
                      : `${formatINR(Math.abs(item.remaining))} over limit`}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
