import React from 'react';
import { Plus, User, Terminal, Menu, LogOut } from 'lucide-react';
import { UserAccount, BackendStatus } from '../types';

interface NavbarProps {
  currentUser: UserAccount;
  backendStatus: BackendStatus;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenAddModal: () => void;
  onOpenProfileModal: () => void;
  onOpenCppHub: () => void;
  onLogout: () => void;
  onToggleMobileMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  backendStatus,
  activeTab,
  onSelectTab,
  onOpenAddModal,
  onOpenProfileModal,
  onOpenCppHub,
  onLogout,
  onToggleMobileMenu,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-4 md:gap-8 px-4 md:px-8 py-3.5 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      {/* Zone 1: Brand Wordmark (Single text element) */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onToggleMobileMenu}
          className="md:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-850"
          aria-label="Toggle navigation drawer"
        >
          <Menu className="w-5 h-5" />
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('dashboard')}
          className="text-left group cursor-pointer"
        >
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0 group-hover:text-emerald-400 transition-colors">
            SmartBudget C++
          </span>
          <span className="hidden sm:inline-block ml-2 text-[11px] font-mono text-slate-400">
            INR (₹) · C++17 SQLite
          </span>
        </button>
      </div>

      {/* Zone 2: Concise Nav Links (Single-line whitespace-nowrap) */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          type="button"
          onClick={() => onSelectTab('dashboard')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'dashboard' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          Dashboard
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('transactions')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'transactions' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          Transactions
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('budget')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'budget' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          Budget & Alerts
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('reports')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'reports' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          Spending Reports
        </button>
        <button
          type="button"
          onClick={onOpenCppHub}
          className={`flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'cpp_backend' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          <span>C++ Backend</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-slate-800 text-slate-300 font-mono">
            {backendStatus.mode === 'cpp_server' ? (backendStatus.isOnline ? 'Online' : 'Offline') : 'Local'}
          </span>
        </button>
      </nav>

      {/* Zone 3: Primary Action & User Profile / Logout */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          type="button"
          onClick={onOpenProfileModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors hover:bg-slate-850"
          title={`Active User: ${currentUser.name}`}
        >
          <User className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden lg:inline truncate max-w-[120px] font-medium">{currentUser.name}</span>
        </button>

        <button
          type="button"
          onClick={onOpenAddModal}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-lg transition-colors shadow-xs whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Add Transaction</span>
        </button>

        <button
          type="button"
          onClick={onLogout}
          className="flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-slate-400 hover:text-rose-300 bg-slate-900 border border-slate-800 hover:border-rose-900/60 rounded-lg transition-colors"
          title="Sign out and return to Login screen"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Logout</span>
        </button>
      </div>
    </header>
  );
};
