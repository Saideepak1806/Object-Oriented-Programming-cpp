import React, { useEffect, useRef } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  AlertTriangle,
  AlertCircle,
  Plus,
  ArrowRight,
  Receipt,
  Sliders,
  Inbox,
  PieChart,
  BarChart3,
} from 'lucide-react';
import {
  Chart,
  ArcElement,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  DoughnutController,
  BarController,
} from 'chart.js';
import { Transaction, BudgetConfig, UserAccount, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { formatINR } from '../utils/currency';

// Register Chart.js components
Chart.register(
  ArcElement,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  DoughnutController,
  BarController
);

interface DashboardViewProps {
  transactions: Transaction[];
  budgetConfig: BudgetConfig;
  currentUser: UserAccount;
  onOpenAddModal: () => void;
  onOpenBudgetModal: () => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (tx: Transaction) => void;
  onNavigateToTransactions: () => void;
  onNavigateToBudget: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  transactions,
  budgetConfig,
  currentUser,
  onOpenAddModal,
  onOpenBudgetModal,
  onEditTransaction,
  onDeleteTransaction,
  onNavigateToTransactions,
  onNavigateToBudget,
}) => {
  const doughnutCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const barCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const doughnutChartInstance = useRef<Chart | null>(null);
  const barChartInstance = useRef<Chart | null>(null);

  // Active month prefix (e.g. "2026-11")
  const currentMonthPrefix = budgetConfig.month;
  const currentMonthTransactions = transactions.filter((tx) =>
    tx.date.startsWith(currentMonthPrefix)
  );

  // 1. Calculate current month financial totals strictly from user data
  const totalIncome = currentMonthTransactions
    .filter((tx) => tx.type === 'income')
    .reduce((acc, tx) => acc + tx.amount, 0);

  const totalExpense = currentMonthTransactions
    .filter((tx) => tx.type === 'expense')
    .reduce((acc, tx) => acc + tx.amount, 0);

  const remainingBalance = totalIncome - totalExpense;

  const hasBudgetSet = budgetConfig.overallLimit > 0;
  const budgetUsagePercent = hasBudgetSet
    ? (totalExpense / budgetConfig.overallLimit) * 100
    : 0;

  // 2. Category-wise expense calculation strictly from user entries
  const categoryExpenses: Record<ExpenseCategory, number> = {
    Food: 0,
    Transport: 0,
    Education: 0,
    Shopping: 0,
    Entertainment: 0,
    Healthcare: 0,
    Others: 0,
  };

  currentMonthTransactions
    .filter((tx) => tx.type === 'expense')
    .forEach((tx) => {
      const cat = tx.category as ExpenseCategory;
      if (categoryExpenses[cat] !== undefined) {
        categoryExpenses[cat] += tx.amount;
      } else {
        categoryExpenses.Others += tx.amount;
      }
    });

  // 3. Calculate overspending alerts ONLY if user has set a budget limit
  const overspentCategories: {
    category: ExpenseCategory;
    spent: number;
    limit: number;
    percent: number;
    status: 'warning' | 'exceeded';
  }[] = [];

  if (hasBudgetSet) {
    (Object.keys(categoryExpenses) as ExpenseCategory[]).forEach((cat) => {
      const spent = categoryExpenses[cat];
      const limit = budgetConfig.categories[cat] || 0;
      if (limit > 0) {
        const percent = (spent / limit) * 100;
        if (percent > 100) {
          overspentCategories.push({ category: cat, spent, limit, percent, status: 'exceeded' });
        } else if (percent >= 80) {
          overspentCategories.push({ category: cat, spent, limit, percent, status: 'warning' });
        }
      }
    });
  }

  const isOverallExceeded = hasBudgetSet && budgetUsagePercent > 100;
  const isOverallWarning = hasBudgetSet && budgetUsagePercent >= 80 && !isOverallExceeded;

  const recentTransactions = transactions.slice(0, 6);
  const hasExpensesThisMonth = currentMonthTransactions.some((t) => t.type === 'expense');
  const hasAnyTransactions = transactions.length > 0;

  // Render Category Doughnut Chart (Only when user has expense records)
  useEffect(() => {
    if (!doughnutCanvasRef.current) return;

    if (doughnutChartInstance.current) {
      doughnutChartInstance.current.destroy();
      doughnutChartInstance.current = null;
    }

    if (!hasExpensesThisMonth) return;

    const categoriesWithSpend = EXPENSE_CATEGORIES.map((cat) => ({
      name: cat.name,
      id: cat.id,
      spent: categoryExpenses[cat.id] || 0,
      color: cat.color,
    })).filter((item) => item.spent > 0);

    if (categoriesWithSpend.length === 0) return;

    const labels = categoriesWithSpend.map((c) => c.name);
    const data = categoriesWithSpend.map((c) => c.spent);
    const backgroundColor = categoriesWithSpend.map((c) => c.color);

    const ctx = doughnutCanvasRef.current.getContext('2d');
    if (!ctx) return;

    doughnutChartInstance.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          {
            data,
            backgroundColor,
            borderColor: '#0f172a',
            borderWidth: 2,
            hoverOffset: 6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 10,
              padding: 10,
              color: '#94a3b8',
              font: {
                size: 11,
                family: "'Plus Jakarta Sans', sans-serif",
              },
            },
          },
          tooltip: {
            backgroundColor: '#090d16',
            borderColor: '#334155',
            borderWidth: 1,
            titleColor: '#f8fafc',
            bodyColor: '#cbd5e1',
            padding: 10,
            callbacks: {
              label: (context) => {
                const value = context.parsed;
                const total = context.dataset.data.reduce((a, b) => (a as number) + (b as number), 0) as number;
                const pct = total > 0 ? ((value / total) * 100).toFixed(1) : '0';
                return ` ${formatINR(value)} (${pct}%)`;
              },
            },
          },
        },
      },
    });

    return () => {
      if (doughnutChartInstance.current) {
        doughnutChartInstance.current.destroy();
      }
    };
  }, [categoryExpenses, hasExpensesThisMonth]);

  // Render Monthly Spending Bar Chart (Only when user has entered transactions)
  useEffect(() => {
    if (!barCanvasRef.current) return;

    if (barChartInstance.current) {
      barChartInstance.current.destroy();
      barChartInstance.current = null;
    }

    if (!hasAnyTransactions) return;

    // Discover months that actually have user transactions
    const monthSet = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.date && tx.date.length >= 7) {
        monthSet.add(tx.date.substring(0, 7));
      }
    });

    // If active month is not in set, add it
    monthSet.add(currentMonthPrefix);
    const sortedMonths = Array.from(monthSet).sort().slice(-4); // Up to 4 active months

    const monthLabels = sortedMonths.map((m) => {
      const parts = m.split('-');
      const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 1);
      return date.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
    });

    const incomeByMonth = sortedMonths.map((m) =>
      transactions
        .filter((tx) => tx.date.startsWith(m) && tx.type === 'income')
        .reduce((sum, tx) => sum + tx.amount, 0)
    );

    const expenseByMonth = sortedMonths.map((m) =>
      transactions
        .filter((tx) => tx.date.startsWith(m) && tx.type === 'expense')
        .reduce((sum, tx) => sum + tx.amount, 0)
    );

    const ctx = barCanvasRef.current.getContext('2d');
    if (!ctx) return;

    barChartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: monthLabels,
        datasets: [
          {
            label: 'Total Income',
            data: incomeByMonth,
            backgroundColor: 'rgba(16, 185, 129, 0.75)',
            borderColor: '#10b981',
            borderWidth: 1,
            borderRadius: 4,
          },
          {
            label: 'Total Expenses',
            data: expenseByMonth,
            backgroundColor: 'rgba(239, 68, 68, 0.75)',
            borderColor: '#ef4444',
            borderWidth: 1,
            borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 12,
              padding: 10,
              color: '#94a3b8',
              font: {
                size: 11,
                family: "'Plus Jakarta Sans', sans-serif",
              },
            },
          },
          tooltip: {
            backgroundColor: '#090d16',
            borderColor: '#334155',
            borderWidth: 1,
            titleColor: '#f8fafc',
            bodyColor: '#cbd5e1',
            padding: 10,
            callbacks: {
              label: (context) => ` ${context.dataset.label}: ${formatINR(context.parsed.y ?? 0)}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: 'rgba(51, 65, 85, 0.25)' },
            ticks: { color: '#94a3b8', font: { size: 11 } },
          },
          y: {
            grid: { color: 'rgba(51, 65, 85, 0.25)' },
            ticks: {
              color: '#94a3b8',
              font: { size: 11 },
              callback: (value) => `₹${value}`,
            },
          },
        },
      },
    });

    return () => {
      if (barChartInstance.current) {
        barChartInstance.current.destroy();
      }
    };
  }, [transactions, currentMonthPrefix, hasAnyTransactions]);

  return (
    <div className="space-y-6">
      {/* View Title & Quick Action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Financial Dashboard
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time balance, spending analytics, and budget tracking for {budgetConfig.month}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onOpenBudgetModal}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-850 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            <span>{hasBudgetSet ? 'Adjust Budget' : 'Set Monthly Budget'}</span>
          </button>
          <button
            type="button"
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Overspending Alerts Section (Active only when user enters transactions & sets budget) */}
      {(isOverallExceeded || isOverallWarning || overspentCategories.length > 0) && (
        <div className="space-y-2.5">
          {isOverallExceeded && (
            <div className="flex items-center justify-between p-3.5 bg-rose-950/60 border border-rose-800/80 rounded-xl text-xs text-rose-200">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                <div>
                  <span className="font-semibold text-rose-300">
                    Monthly Budget Exceeded:
                  </span>{' '}
                  You have spent <span className="font-mono font-bold">{formatINR(totalExpense)}</span> of your {formatINR(budgetConfig.overallLimit)} limit ({budgetUsagePercent.toFixed(1)}%).
                </div>
              </div>
              <button
                onClick={onNavigateToBudget}
                className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-rose-300 hover:text-white underline shrink-0 ml-3"
              >
                Review Limits <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {isOverallWarning && (
            <div className="flex items-center justify-between p-3.5 bg-amber-950/50 border border-amber-800/70 rounded-xl text-xs text-amber-200">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <span className="font-semibold text-amber-300">
                    Monthly Budget Warning:
                  </span>{' '}
                  You have reached <span className="font-mono font-bold">{budgetUsagePercent.toFixed(1)}%</span> of your monthly budget limit ({formatINR(totalExpense)} / {formatINR(budgetConfig.overallLimit)}).
                </div>
              </div>
              <button
                onClick={onNavigateToBudget}
                className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-amber-300 hover:text-white underline shrink-0 ml-3"
              >
                Adjust Plan <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {overspentCategories.map((alert) => (
            <div
              key={alert.category}
              className={`flex items-center justify-between p-3 rounded-lg border text-xs ${
                alert.status === 'exceeded'
                  ? 'bg-rose-950/40 border-rose-900/60 text-rose-300'
                  : 'bg-amber-950/30 border-amber-900/50 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className={`w-2 h-2 rounded-full ${alert.status === 'exceeded' ? 'bg-rose-500' : 'bg-amber-400'}`} />
                <span>
                  <strong className="text-white">{alert.category}</strong>{' '}
                  {alert.status === 'exceeded' ? 'crossed 100% budget limit:' : 'approaching limit (≥80%):'}{' '}
                  <span className="font-mono font-medium">{formatINR(alert.spent)}</span> spent of {formatINR(alert.limit)} ({alert.percent.toFixed(1)}%)
                </span>
              </div>
              <button
                onClick={onOpenBudgetModal}
                className="text-[11px] text-slate-400 hover:text-white underline shrink-0 ml-2"
              >
                Adjust
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 4 Primary KPI Summary Cards (Defaults to ₹0.00 for new users) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Total Income */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Total Income</span>
            <div className="p-2 bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {formatINR(totalIncome)}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
            <span>Inflows for {budgetConfig.month}</span>
            <span className="text-emerald-400 font-mono font-medium">
              {currentMonthTransactions.filter((t) => t.type === 'income').length} entries
            </span>
          </div>
        </div>

        {/* 2. Total Expenses */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Total Expenses</span>
            <div className="p-2 bg-rose-950/60 text-rose-400 border border-rose-800/40 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {formatINR(totalExpense)}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
            <span>Outflows for {budgetConfig.month}</span>
            <span className="text-rose-400 font-mono font-medium">
              {currentMonthTransactions.filter((t) => t.type === 'expense').length} entries
            </span>
          </div>
        </div>

        {/* 3. Remaining Balance */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Remaining Balance</span>
            <div className="p-2 bg-blue-950/60 text-blue-400 border border-blue-800/40 rounded-lg">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div
            className={`text-2xl font-bold font-mono tabular-nums ${
              remainingBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {formatINR(remainingBalance, true)}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
            <span>Net cash balance</span>
            <span className="font-mono text-slate-300">
              Savings rate: {totalIncome > 0 ? ((remainingBalance / totalIncome) * 100).toFixed(1) : '0.0'}%
            </span>
          </div>
        </div>

        {/* 4. Monthly Budget Usage */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Monthly Budget Usage</span>
            <div className="p-2 bg-violet-950/60 text-violet-400 border border-violet-800/40 rounded-lg">
              <PiggyBank className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {hasBudgetSet ? `${budgetUsagePercent.toFixed(1)}%` : '0.0%'}
            </span>
            <span className="text-xs font-mono text-slate-400">
              {hasBudgetSet ? `of ${formatINR(budgetConfig.overallLimit)}` : 'Limit not set'}
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800/80">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                isOverallExceeded
                  ? 'bg-rose-500'
                  : isOverallWarning
                  ? 'bg-amber-400'
                  : 'bg-emerald-400'
              }`}
              style={{ width: `${Math.min(budgetUsagePercent, 100)}%` }}
            />
          </div>

          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-0.5">
            {hasBudgetSet ? (
              <span>
                {budgetConfig.overallLimit >= totalExpense
                  ? `${formatINR(budgetConfig.overallLimit - totalExpense)} cushion`
                  : `${formatINR(totalExpense - budgetConfig.overallLimit)} over budget`}
              </span>
            ) : (
              <span>Click to define monthly cap</span>
            )}
            <button
              onClick={onNavigateToBudget}
              className="text-emerald-400 hover:text-emerald-300 transition-colors font-medium"
            >
              {hasBudgetSet ? 'Details' : 'Set Budget'}
            </button>
          </div>
        </div>
      </div>

      {/* Charts Grid: Category-wise Expense Chart & Monthly Spending Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Category-wise Expense Chart (Doughnut) */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white">Category-wise Expense Chart</h2>
              <p className="text-xs text-slate-400">Distribution for {budgetConfig.month}</p>
            </div>
            {hasExpensesThisMonth && (
              <button
                type="button"
                onClick={onNavigateToBudget}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
              >
                View Limits
              </button>
            )}
          </div>

          <div className="relative flex-1 min-h-[260px] flex items-center justify-center">
            {hasExpensesThisMonth ? (
              <canvas ref={doughnutCanvasRef} />
            ) : (
              <div className="text-center p-6 space-y-2">
                <PieChart className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs font-medium text-slate-300">
                  No expense records yet for this month
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Add your first expense transaction to automatically generate this category doughnut chart.
                </p>
                <button
                  type="button"
                  onClick={onOpenAddModal}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-emerald-400 rounded-md transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Expense</span>
                </button>
              </div>
            )}
          </div>

          {/* Category breakdown quick summary (shown when expenses exist) */}
          {hasExpensesThisMonth && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-4 mt-2 border-t border-slate-800/60 text-xs">
              {EXPENSE_CATEGORIES.slice(0, 4).map((cat) => {
                const spent = categoryExpenses[cat.id] || 0;
                return (
                  <div key={cat.id} className="p-2 bg-slate-950/60 rounded-lg border border-slate-800/80">
                    <div className="flex items-center gap-1.5 text-slate-400 truncate">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                      <span className="truncate">{cat.id}</span>
                    </div>
                    <div className="text-xs font-mono font-semibold text-white mt-1 tabular-nums">
                      {formatINR(spent)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Chart 2: Monthly Spending Chart (Bar) */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white">Monthly Spending Chart</h2>
              <p className="text-xs text-slate-400">Income vs expenses comparison</p>
            </div>
            {hasAnyTransactions && (
              <button
                type="button"
                onClick={onNavigateToTransactions}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
              >
                All Records
              </button>
            )}
          </div>

          <div className="relative flex-1 min-h-[260px] flex items-center justify-center">
            {hasAnyTransactions ? (
              <canvas ref={barCanvasRef} />
            ) : (
              <div className="text-center p-6 space-y-2">
                <BarChart3 className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs font-medium text-slate-300">
                  No transactions recorded yet
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Add income or expense entries to visualize cashflow trends across calendar months.
                </p>
                <button
                  type="button"
                  onClick={onOpenAddModal}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-emerald-400 rounded-md transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Record Transaction</span>
                </button>
              </div>
            )}
          </div>

          {hasAnyTransactions && (
            <div className="flex items-center justify-between pt-4 mt-2 border-t border-slate-800/60 text-xs text-slate-400">
              <span>Timeline: Active recorded periods</span>
              <span className="text-slate-300 font-mono">
                Net savings: {formatINR(totalIncome - totalExpense, true)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Recent Transactions List with Working Actions */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white">Recent Transactions</h2>
            <p className="text-xs text-slate-400">Latest recorded financial entries</p>
          </div>
          {hasAnyTransactions && (
            <button
              type="button"
              onClick={onNavigateToTransactions}
              className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-medium transition-colors"
            >
              <span>View All ({transactions.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Transactions Table or Empty State (Requirement 2) */}
        {recentTransactions.length === 0 ? (
          <div className="py-12 text-center space-y-3 bg-slate-950/40 border border-dashed border-slate-800 rounded-xl p-6">
            <Inbox className="w-10 h-10 text-slate-600 mx-auto" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-300">
                No transactions yet. Add your first transaction.
              </p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Your income, expenses, and budget utilization will update here immediately in real-time.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add Your First Transaction</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Method</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    className="hover:bg-slate-850/50 transition-colors group"
                  >
                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-200 truncate max-w-[220px]">
                        {tx.description}
                      </div>
                      {tx.notes && (
                        <div className="text-[11px] text-slate-400 truncate max-w-[220px]">
                          {tx.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{
                            backgroundColor:
                              tx.type === 'expense'
                                ? EXPENSE_CATEGORIES.find((c) => c.id === tx.category)?.color || '#94a3b8'
                                : '#10b981',
                          }}
                        />
                        <span>{tx.category}</span>
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 whitespace-nowrap font-mono">
                      {tx.date}
                    </td>
                    <td className="py-3 px-3 text-slate-400 whitespace-nowrap">
                      {tx.paymentMethod}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold whitespace-nowrap tabular-nums">
                      <span
                        className={
                          tx.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'
                        }
                      >
                        {formatINR(tx.amount, true)}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5 opacity-90 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={() => onEditTransaction(tx)}
                          className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
                          title="Edit Transaction"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteTransaction(tx)}
                          className="p-1 text-slate-400 hover:text-rose-400 rounded-md hover:bg-slate-800 transition-colors"
                          title="Delete Transaction"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
