@echo off
echo ========================================================
echo  Personal Expense Tracker - System Diagnostic Tool
echo ========================================================
echo.

echo [1] Checking Node.js (for Web Dashboard)...
node -v 2>nul
if %errorlevel% equ 0 (
    echo     SUCCESS: Node.js is installed.
) else (
    echo     NOTE: Node.js not detected. Download from https://nodejs.org
)

echo.
echo [2] Checking npm (package manager)...
npm -v 2>nul
if %errorlevel% equ 0 (
    echo     SUCCESS: npm is installed.
) else (
    echo     NOTE: npm not detected.
)

echo.
echo [3] Checking g++ (for C++ Backend compilation)...
where g++ 2>nul
if %errorlevel% equ 0 (
    echo     SUCCESS: g++ found in PATH!
    g++ --version | findstr /i "g++ gcc version"
) else (
    echo     NOTE: g++ is not in your Windows PATH.
    echo     To install GCC on Windows, run:
    echo        winget install -e --id winlibs.winlibs-llvm-mingw-ucrt
)

echo.
echo ========================================================
echo  RECOMMENDED NEXT STEP:
echo ========================================================
echo  To run the full Web Dashboard right now, simply run:
echo     npm install
echo     npm run dev
echo  and open http://localhost:3000 in your browser!
echo ========================================================
echo.
pause
