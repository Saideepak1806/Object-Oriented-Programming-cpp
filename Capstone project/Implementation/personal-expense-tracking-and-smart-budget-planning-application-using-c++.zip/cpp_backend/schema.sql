-- SQLite Schema for Personal Expense Tracking and Smart Budget Planning Application
-- Standard Currency: Indian Rupee (₹ INR)
-- Compatible with SQLite3 and C++17 cpp-httplib backend

PRAGMA foreign_keys = ON;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    currency TEXT DEFAULT '₹',
    role TEXT DEFAULT 'Personal Budget User',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Budgets Table (user-controlled per month and category in INR)
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    month TEXT NOT NULL, -- Format: YYYY-MM
    category TEXT NOT NULL, -- 'Overall' or specific ExpenseCategory
    budget_limit REAL NOT NULL, -- Limit in INR (₹)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, month, category),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Transactions Table (user-scoped records)
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
    amount REAL NOT NULL CHECK(amount > 0), -- Amount in INR (₹)
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    date TEXT NOT NULL, -- Format: YYYY-MM-DD
    payment_method TEXT NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Indices for rapid querying and monthly summaries
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category);
CREATE INDEX IF NOT EXISTS idx_budgets_lookup ON budgets(user_id, month);
