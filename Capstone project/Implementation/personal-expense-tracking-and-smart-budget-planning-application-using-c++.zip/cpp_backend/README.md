# C++17 SQLite Backend Architecture for Personal Expense Tracker

This folder provides the native C++17 REST backend architecture for the Personal Expense Tracking and Smart Budget Planning Application in Indian Rupees (**₹ INR**).

---

## Why did you see `fatal error: sqlite3.h: No such file or directory` on Windows?

On Windows, standard MinGW/GCC installations do not include the SQLite3 C library headers (`sqlite3.h`) by default.
You have two quick and easy solutions to fix this:

---

### Option 1 (Easiest for Windows - Double-Click Script)

Inside the `cpp_backend` folder, simply double-click:
```cmd
build_windows.bat
```
*(Or in Command Prompt run: `build_windows.bat`)*

This script automatically:
1. Downloads the official single-file SQLite source files (`sqlite3.h` and `sqlite3.c`).
2. Downloads `httplib.h` and `json.hpp`.
3. Compiles `expense_server.exe` with `g++ -std=c++17 main.cpp sqlite3.c -lws2_32 -lpthread -O2 -o expense_server.exe`.
4. Starts the server on `http://localhost:8080`.

---

### Option 2 (Manual Command in Windows Command Prompt)

Run these 4 commands in your Command Prompt (`cmd.exe`) inside `cpp_backend`:

```cmd
:: 1. Download sqlite3.h and sqlite3.c into the cpp_backend folder
curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.h -o sqlite3.h
curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.c -o sqlite3.c

:: 2. Download httplib.h and json.hpp
curl -sL https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h -o httplib.h
curl -sL https://raw.githubusercontent.com/nlohmann/json/develop/single_include/nlohmann/json.hpp -o json.hpp

:: 3. Compile (combines sqlite3.c directly and links ws2_32 for Windows networking)
g++ -std=c++17 main.cpp sqlite3.c -lws2_32 -lpthread -O2 -o expense_server.exe

:: 4. Run the executable
expense_server.exe 8080
```

---

### Option 3 (If using MSYS2 on Windows)
If you use the MSYS2 environment:
```bash
pacman -S mingw-w64-x86_64-sqlite3
g++ -std=c++17 main.cpp -lsqlite3 -lws2_32 -lpthread -O2 -o expense_server.exe
./expense_server.exe 8080
```

---

### Option 4 (Linux / WSL)
```bash
sudo apt-get update
sudo apt-get install -y build-essential libsqlite3-dev
make
./expense_server 8080
```

---

## Reminder: Web App Runs Independently!
You do **not** need the C++ server running to use the application!
The web frontend (`npm run dev` at `http://localhost:3000`) has a complete interactive prototype engine with localStorage persistence. The C++ server is an optional demonstration of the backend architecture.
