@echo off
echo ========================================================
echo  Building C++17 SQLite Backend for Windows
echo ========================================================

cd /d "%~dp0"

:: 1. Verify / Auto-detect g++ in PATH
where g++ >nul 2>nul
if %errorlevel% neq 0 (
    echo [Diagnostic] g++ not found in default PATH. Checking common MinGW locations...
    if exist "C:\msys64\ucrt64\bin\g++.exe" (
        set "PATH=%PATH%;C:\msys64\ucrt64\bin"
        echo [Found] Added C:\msys64\ucrt64\bin to PATH
    ) else if exist "C:\msys64\mingw64\bin\g++.exe" (
        set "PATH=%PATH%;C:\msys64\mingw64\bin"
        echo [Found] Added C:\msys64\mingw64\bin to PATH
    ) else if exist "C:\MinGW\bin\g++.exe" (
        set "PATH=%PATH%;C:\MinGW\bin"
        echo [Found] Added C:\MinGW\bin to PATH
    ) else if exist "C:\Program Files\CodeBlocks\MinGW\bin\g++.exe" (
        set "PATH=%PATH%;C:\Program Files\CodeBlocks\MinGW\bin"
        echo [Found] Added CodeBlocks MinGW to PATH
    ) else if exist "C:\w64devkit\bin\g++.exe" (
        set "PATH=%PATH%;C:\w64devkit\bin"
        echo [Found] Added w64devkit to PATH
    )
)

where g++ >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo ========================================================
    echo  [ERROR] g++ compiler was NOT found on your system!
    echo ========================================================
    echo MinGW C++ compiler is required to build expense_server.exe.
    echo.
    echo Quick install with winget:
    echo   winget install -e --id winlibs.winlibs-llvm-mingw-ucrt
    echo ========================================================
    pause
    exit /b 1
)

echo [Compiler] Detected g++:
g++ --version | findstr /i "g++ gcc version"

:: 2. Download missing dependencies
if not exist "httplib.h" (
    echo Downloading httplib.h...
    curl -sL https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h -o httplib.h
)

if not exist "json.hpp" (
    echo Downloading json.hpp...
    curl -sL https://raw.githubusercontent.com/nlohmann/json/develop/single_include/nlohmann/json.hpp -o json.hpp
)

if not exist "sqlite3.h" (
    echo Downloading sqlite3.h...
    curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.h -o sqlite3.h
)

if not exist "sqlite3.c" (
    echo Downloading sqlite3.c...
    curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.c -o sqlite3.c
)

:: 3. Compile
echo.
echo Compiling expense_server.exe...
g++ -std=c++17 main.cpp sqlite3.c -lws2_32 -lpthread -O2 -o expense_server.exe

if %errorlevel% equ 0 (
    echo ========================================================
    echo  BUILD SUCCESSFUL!
    echo  Launching C++17 Server on http://localhost:8080
    echo ========================================================
    expense_server.exe 8080
) else (
    echo.
    echo [ERROR] Compilation failed. See error output above.
)
pause
