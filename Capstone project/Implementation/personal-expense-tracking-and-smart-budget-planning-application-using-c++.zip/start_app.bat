@echo off
echo ========================================================
echo  Personal Expense Tracker - Web Application (Frontend)
echo ========================================================

cd /d "%~dp0"

echo 1. Checking npm dependencies...
call npm install

echo.
echo 2. Launching Web Dashboard on http://localhost:3000 ...
call npm run dev
pause
