@echo off
echo ========================================================
echo  Personal Expense Tracker - C++17 SQLite Backend Builder
echo ========================================================

cd /d "%~dp0cpp_backend"

echo Current folder: %CD%

:: 1. Verify / Auto-detect g++ in PATH
where g++ >nul 2>nul
if %errorlevel% neq 0 (
    echo [Diagnostic] g++ not found in default PATH. Checking common MinGW locations...
    if exist "C:\msys64\ucrt64\bin\g++.exe" (
        set "PATH=%PATH%;C:\msys64\ucrt64\bin"
        echo [Found] Added C:\msys64\ucrt64\bin to PATH
    ) else if exist "C:\msys64\mingw64\bin\g++.exe" (
        set "PATH=%PATH%;C:\msys64\mingw64\bin"
        echo [Found] Added C:\msys64\mingw64\bin to PATH
    ) else if exist "C:\MinGW\bin\g++.exe" (
        set "PATH=%PATH%;C:\MinGW\bin"
        echo [Found] Added C:\MinGW\bin to PATH
    ) else if exist "C:\Program Files\CodeBlocks\MinGW\bin\g++.exe" (
        set "PATH=%PATH%;C:\Program Files\CodeBlocks\MinGW\bin"
        echo [Found] Added CodeBlocks MinGW to PATH
    ) else if exist "C:\w64devkit\bin\g++.exe" (
        set "PATH=%PATH%;C:\w64devkit\bin"
        echo [Found] Added w64devkit to PATH
    )
)

where g++ >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo ========================================================
    echo  [ERROR] g++ compiler was NOT found on your system!
    echo ========================================================
    echo MinGW C++ compiler is required to build expense_server.exe.
    echo.
    echo How to install g++ in 1 minute on Windows:
    echo 1. Open a new Command Prompt or PowerShell and run:
    echo       winget install -e --id winlibs.winlibs-llvm-mingw-ucrt
    echo.
    echo 2. Or download MinGW-w64 from: https://winlibs.com
    echo    and extract it to C:\mingw64, then add C:\mingw64\bin to PATH.
    echo.
    echo NOTE: The Web Dashboard (npm run dev) runs completely
    echo independently without needing the C++ backend compiled!
    echo ========================================================
    pause
    exit /b 1
)

echo [Compiler] Detected g++:
g++ --version | findstr /i "g++ gcc version"

:: 2. Download missing headers if needed
if not exist "httplib.h" (
    echo Downloading httplib.h...
    curl -sL https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h -o httplib.h
)

if not exist "json.hpp" (
    echo Downloading json.hpp...
    curl -sL https://raw.githubusercontent.com/nlohmann/json/develop/single_include/nlohmann/json.hpp -o json.hpp
)

if not exist "sqlite3.h" (
    echo Downloading sqlite3.h...
    curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.h -o sqlite3.h
)

if not exist "sqlite3.c" (
    echo Downloading sqlite3.c...
    curl -sL https://raw.githubusercontent.com/mattn/sqlite-amalgamation/master/sqlite3.c -o sqlite3.c
)

:: 3. Compile and link
echo.
echo Compiling C++17 SQLite backend (expense_server.exe)...
echo Running: g++ -std=c++17 main.cpp sqlite3.c -lws2_32 -lpthread -O2 -o expense_server.exe
g++ -std=c++17 main.cpp sqlite3.c -lws2_32 -lpthread -O2 -o expense_server.exe

if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo  SUCCESS: expense_server.exe compiled successfully!
    echo  Starting C++17 Server on http://localhost:8080 ...
    echo ========================================================
    expense_server.exe 8080
) else (
    echo.
    echo ========================================================
    echo  [ERROR] Compilation failed. See compiler output above.
    echo ========================================================
)
pause
